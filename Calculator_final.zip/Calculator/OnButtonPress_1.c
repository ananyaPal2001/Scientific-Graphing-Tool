
#include "Initial_1.h"
#include"all_functions.h"

//*****************************************************************************
//
// Handles press notifications for the push button widgets.
//
//*****************************************************************************
void
OnButtonPress_1(tWidget *psWidget)
{
    uint32_t button_1;

       //
       // Find the index of this push button.
       //
       for(button_1 = 0; button_1 < NUM_PUSH_BUTTONS_1; button_1++)
       {
           if(psWidget == (tWidget *)(g_psPushButtons_1 + button_1))
           {
               break;
           }
       }

       //
       // Return if the push button could not be found.
       //
       if(button_1 == NUM_PUSH_BUTTONS_1)
       {
           return;
       }
       switch(button_1)
       {

       case 0 :
           char_pressed[index] = '1';
           index++;
           break;
       case 1 :
           char_pressed[index] = '2';
           index++;
           break;
       case 2 :
           char_pressed[index] = '3';
           index++;
           break;

       case 3 :
           char_pressed[index] = '4';
           index++;
           break;
       case 4 :
           char_pressed[index] = '5';
           index++;
           break;

       case 5 :
           char_pressed[index]= '6';
           index++;
           break;
       case 6 :
           char_pressed[index] = '7';
           index++;
           break;
       case 7 :
           char_pressed[index] = '8';
           index++;
           break;
       case 8 :
           char_pressed[index] = '9';
           index++;
           break;
       case 9 :
           char_pressed[index] = '0';
           index++;
           break;

       case 10 :
           char_pressed[index] = '.';
           index++;
           break;

       case 11 ://clear
           memset(char_pressed,0,sizeof(char_pressed));
           memset(operators,0,sizeof(operators));
           memset(operand,0,sizeof(operand));
           memset(operand_array,0,sizeof(operand_array));
           memset(result,0,sizeof(result));
           index=0;
           break;
       case 12 ://backspace
           index--;
          char_pressed[index] = 0;
           break;
       case 13 ://calculation
           processing();
           calculation();
           break;
       case 14 :
           result_update();
           char_pressed[index] = '+';
           index++;
           break;
       case 15 :
           result_update();
           char_pressed[index] = '-';
           index++;
           break;
       case 16 :
           result_update();
           char_pressed[index] = 'x';
           index++;
           break;
       case 17 :
           result_update();
           char_pressed[index] = '/';
           index++;
           break;
       default :
           return;
          // break;

       }

       CanvasTextSet(&g_sCanvas_11, char_pressed);
       WidgetPaint((tWidget *)&g_sCanvas_11);
       display_result_1();
       g_ui32ButtonState_1 ^= 1 << button_1;

}

void display_result_1(void){
    if(operand_array[0]==0 & operand_array[3]==0)Display("0.00000");
    if(operand_array[0]<0){
        result[0]='-';
        float a=(0-operand_array[0]);
        ftoa(a, &result[1], 4);
        CanvasTextSet(&g_sCanvas_21, result);
        WidgetPaint((tWidget *)&g_sCanvas_21);
    }
    else if(operand_array[0]>0){
        ftoa(operand_array[0], result, 4);
        CanvasTextSet(&g_sCanvas_21, result);
        WidgetPaint((tWidget *)&g_sCanvas_21);
    }
    else{
        CanvasTextSet(&g_sCanvas_21, result);
                WidgetPaint((tWidget *)&g_sCanvas_21);
    }


}
