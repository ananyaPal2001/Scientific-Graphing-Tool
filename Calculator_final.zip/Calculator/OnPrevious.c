
#include "Initial_1.h"
#include"all_functions.h"

//*****************************************************************************
//
// The panel that is currently being displayed.
//
//*****************************************************************************


char *g_pcPanei32Names[] =
{
    "     Home     ",
    "     S/W Update    "
};

//*****************************************************************************
//
// The buttons and text across the bottom of the screen.
//
//*****************************************************************************



RectangularButton(g_sPrevious, 0, 0, 0, &g_sKentec320x240x16_SSD2119, 0 , 200, 40, 40,
                  PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                                            &g_sFontCm22, "prev", g_pui8Blue50x50,
                                            g_pui8Blue50x50Press, 0, 0,OnPrevious);

Canvas(g_sTitle, 0, 0, 0, &g_sKentec320x240x16_SSD2119, 50, 190, 220, 50,
       CANVAS_STYLE_TEXT | CANVAS_STYLE_TEXT_OPAQUE, 0, 0, ClrSilver,
       &g_sFontCm20, 0, 0, 0);
//*****************************************************************************
//
// Handles presses of the previous panel button.
//
//*****************************************************************************
void
OnPrevious(tWidget *psWidget)
{
    //
    // There is nothing to be done if the first panel is already being
    // displayed.
    //
    if(g_ui32Panel == 0)
    {
        return;
    }

    //
    // Remove the current panel.
    //
    WidgetRemove((tWidget *)(g_psPanels + g_ui32Panel));

    //
    // Decrement the panel index.
    //
    //g_ui32Panel--;

    //
    // Add and draw the new panel.
    // if plotting window change to the equation entering window
    if(g_ui32Panel == 7) {
        g_ui32Panel--;
        WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + g_ui32Panel));
        WidgetPaint((tWidget *)(g_psPanels + g_ui32Panel));
    } else {
        WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels));
        WidgetPaint((tWidget *)(g_psPanels));

        PushButtonFillOn(&g_sPrevious);
        PushButtonTextOn(&g_sPrevious);
        PushButtonOutlineOff(&g_sPrevious);
       // PushButtonFillOn(&g_sPrevious);
        WidgetPaint((tWidget *)&g_sPrevious);
        g_ui32Panel = 0;
    }

    //


    //
    // See if this is the first panel.
    //
   // if(g_ui32Panel == 0)
    //{
        //


        memset(char_pressed,0,sizeof(char_pressed));
        memset(operators,0,sizeof(operators));
        memset(operand,0,sizeof(operand));
        memset(operand_array,0,sizeof(operand_array));
        memset(result,0,sizeof(result));
        memset(disp_array,0,sizeof(disp_array));
        index=0;
        DataConv_fun=0;
        disp_in=0;

}
