
#ifndef INITIAL_1_H_
#define INITIAL_1_H_
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "inc/hw_memmap.h"
#include "inc/hw_nvic.h"
#include "inc/hw_sysctl.h"
#include "inc/hw_types.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/flash.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/uart.h"
#include "driverlib/udma.h"
#include "driverlib/rom.h"
#include "grlib/grlib.h"
#include "grlib/widget.h"
#include "grlib/canvas.h"
#include "grlib/checkbox.h"
#include "grlib/container.h"
#include "grlib/pushbutton.h"
#include "grlib/radiobutton.h"
#include "grlib/slider.h"
#include "utils/ustdlib.h"
#include "D:\IISc Acad Related\Semester 2\Embedded System Design\Lab\TivaWare_C_Series-2.2.0.295\examples\boards\ek-tm4c123gxl-boostxl-kentec-s1\drivers\Kentec320x240x16_ssd2119_spi.h"
#include "D:\IISc Acad Related\Semester 2\Embedded System Design\Lab\TivaWare_C_Series-2.2.0.295\examples\boards\ek-tm4c123gxl-boostxl-kentec-s1\drivers\touch.h"
#include "images.h"

#define MAX_EXPR_SIZE 128
#define TOTAL_POINTS 600

char char_pressed[40];
extern int index;
char operators[9];
char operand[10];
float  operand_array[10];
char result[20];
extern int no_of_operator;
char disp_array[40];
extern int disp_in;
char temp[10];
int str_len,length;
float tirg_result;
float Eval_result;
int function_index;
int n, r,check_var;

// Data converters
char char_pressed_3[20];
extern int DataConv_idx;
char input_data_type[3], output_data_type[3];
extern int DataConv_fun;
char result_3[20];

//age calculator

char dob[12];
extern int eq_in;
char current_date[12];
extern int b_in;
char age[30];
extern int a_in;
extern char dob_dis[10];
extern char current_dis[10];
int present_date;
int present_month;
int present_year ;
int a;
int b;
int c;
int final_date;
int final_month;
int final_year;
char temp_char[5];
extern bool deg_colour;
extern bool single_num;
extern char pi_char[9];

void processing(void);
void calculation(void);
void Display(char *);
void result_update(void);
long int factorial(int );
void display_result_1(void);
void display_result_2(void);
void display_result_5(void);

void ftoa(float , char *, int);
int intToStr(int , char str[], int );
void reverse(char *, int );

// Graphing calculator
void display_result_6(void);
//int points[30][2];


//panels variables
extern int NUM_PANELS;
extern int Home_buttons;
uint32_t g_ui32ButtonState_home;
extern int NUM_PUSH_BUTTONS_1;
uint32_t g_ui32ButtonState_1;
extern int  NUM_PUSH_BUTTONS_2;
uint32_t g_ui32ButtonState_2;
extern int  NUM_PUSH_BUTTONS_3;
uint32_t g_ui32ButtonState_3;
extern int  NUM_PUSH_BUTTONS_4;
uint32_t g_ui32ButtonState_4;
extern int  NUM_PUSH_BUTTONS_5;
uint32_t g_ui32ButtonState_5;
//********** Graph Plotter Panel **********//
extern int  NUM_PUSH_BUTTONS_6;
uint32_t g_ui32ButtonState_6;
extern int  NUM_PUSH_BUTTONS_6_2;
uint32_t g_ui32ButtonState_6_2;
#endif /* INITIAL_1_H_ */
