
#include "Initial_1.h"
#include"all_functions.h"
#include "stdio.h"
void data_process(void);
void age_calculate(int,int,int);

void
OnButtonPress_4(tWidget *psWidget)
{
    uint32_t button_4;

    //
    // Find the index of this push button.
    //
    for(button_4 = 0; button_4 < NUM_PUSH_BUTTONS_4; button_4++)
    {
        if(psWidget == (tWidget *)(g_psPushButtons_4 + button_4))
        {
            break;
        }
    }

    //
    // Return if the push button could not be found.
    //
    if(button_4 == NUM_PUSH_BUTTONS_4)
    {
        return;
    }
    switch(button_4)
        {

        case 0 :
            if(eq_in==10){
                current_date[b_in]='1';
                b_in++;
            }
            else{
                dob[eq_in]='1';
                eq_in++;
            }
            break;
        case 1 :
            if(eq_in==10){
                current_date[b_in]='2';
                b_in++;
            }
            else{
                dob[eq_in]='2';
                eq_in++;
            }
            break;
        case 2 :
            if(eq_in==10){
                current_date[b_in]='3';
                b_in++;
            }
            else{
                dob[eq_in]='3';
                eq_in++;
            }
            break;

        case 3 :
            if(eq_in==10){
                current_date[b_in]='4';
                b_in++;
            }
            else{
                dob[eq_in]='4';
                eq_in++;
            }
            break;
        case 4 :
            if(eq_in==10){
                current_date[b_in]='5';
                b_in++;
            }
            else{
                dob[eq_in]='5';
                eq_in++;
            }
            break;

        case 5 :
            if(eq_in==10){
                current_date[b_in]='6';
                b_in++;
            }
            else{
                dob[eq_in]='6';
                eq_in++;
            }
            break;
        case 6 :
            if(eq_in==10){
                current_date[b_in]='7';
                b_in++;
            }
            else{
                dob[eq_in]='7';
                eq_in++;
            }
            break;
        case 7 :
            if(eq_in==10){
                current_date[b_in]='8';
                b_in++;
            }
            else{
                dob[eq_in]='8';
                eq_in++;
            }
            break;
        case 8 :
            if(eq_in==10){
                current_date[b_in]='9';
                b_in++;
            }
            else{
                dob[eq_in]='9';
                eq_in++;
            }
            break;
        case 9 :
            if(eq_in==10){
                current_date[b_in]='0';
                b_in++;
            }
            else{
                dob[eq_in]='0';
                eq_in++;
            }
            break;

        case 10 :
            if(eq_in==10){
                current_date[b_in]=',';
                b_in++;
            }
            else{
                dob[eq_in]=',';
                eq_in++;
            }
            break;

        case 11 ://delete
            if(eq_in==10){
                b_in--;
                 current_date[b_in]=0;
                if(b_in==0){
                    eq_in--;
                    dob[eq_in]=0;
                }
             }
             else{
                 eq_in--;
                 dob[eq_in]=0;
             }
            break;
        case 12 ://clear all
            memset(dob,0,sizeof(dob));
            eq_in=0;
            memset(current_date,0,sizeof(current_date));
            b_in=0;
            memset(age,0,sizeof(age));
            a_in=0;

            CanvasTextSet(&g_sCanvas_64, age);
            WidgetPaint((tWidget *)&g_sCanvas_64);
            break;
        case 13:// =
            data_process();
            age_calculate(a, b, c);
            break;
        case 14:// =
            if(eq_in==10){
                            current_date[b_in]='-';
                            b_in++;
                        }
                        else{
                            dob[eq_in]='-';
                            eq_in++;
                        }
                   break;

        }

    CanvasTextSet(&g_sCanvas_24, dob);
    WidgetPaint((tWidget *)&g_sCanvas_24);
    CanvasTextSet(&g_sCanvas_44, current_date);
    WidgetPaint((tWidget *)&g_sCanvas_44);

    //
    // Toggle the state of this push button indicator.
    //
    g_ui32ButtonState_4 ^= 1 << button_4;

}
void data_process(void){
    int i=0,j=0;
    char temp_d[5];
    while(dob[i]!=0){
        temp_d[j]=dob[i];
        j++;
        if(dob[i]==','){
            if(i==2){
                j--;
                temp_d[j]=0;
                a  =atoi(temp_d);
                memset(temp_d,0,sizeof(temp_d));
                j=0;
            }
            else{
                j--;
                temp_d[j]=0;
                b =atoi(temp_d);
                memset(temp_d,0,sizeof(temp_d));
                j=0;
            }

        }
        i++;
    }
    c =atoi(temp_d);
    memset(temp_d,0,sizeof(temp_d));
    i=0;
    j=0;

    while(current_date[i]!=0){
        temp_d[j]=current_date[i];
        j++;
        if(current_date[i]==','){
            if(i==2){
                j--;
                temp_d[j]=0;
                present_date =atoi(temp_d);
                memset(temp_d,0,sizeof(temp_d));
                j=0;
            }
            else{
                j--;
                temp_d[j]=0;
                present_month =atoi(temp_d);
                memset(temp_d,0,sizeof(temp_d));
                j=0;
            }

        }
        i++;
    }
    memset(temp_d,0,sizeof(temp_d));
    i=0;
    j=0;
}
void age_calculate(int a, int b, int c) {
    double r1,r2;
    char age1[5];
    char age2[5];
       if(((b*b)-(4*a*c))>0)
       {
           r1=(double)(-b+sqrt(b*b-(4*a*c)))/(2*a);
           r2=(double)(-b-(sqrt(b*b-(4*a*c))))/(2*a);
       }
      printf(age1,"%.2f",r1);
      printf(age2,"%.2f",r2);
      strcat(age,age1);
      strcat(age,",");
      strcat(age,age2);
  CanvasTextSet(&g_sCanvas_64, age);
  WidgetPaint((tWidget *)&g_sCanvas_64);

}

