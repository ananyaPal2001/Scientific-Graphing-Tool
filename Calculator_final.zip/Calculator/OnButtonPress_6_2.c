#include <stdio.h>
#include "Initial_1.h"
#include "all_functions.h"
#include "evaluate.h"

void OnButtonPress_6_2(tWidget *psWidget, tContext *psContext)
{
    uint32_t ui32Idx;

    // Draw vertical lines
    for(ui32Idx = 10; ui32Idx <= 320; ui32Idx += 5)
    {
//        // Set color for drawing the lines
        GrContextForegroundSet(psContext, ClrSilver);
        GrLineDraw(psContext, ui32Idx, 0, ui32Idx, 189);

    }

    // Draw horizontal lines
    for(ui32Idx = 0; ui32Idx <= 190; ui32Idx += 3)
    {
        // Set color for drawing the lines
        GrContextForegroundSet(psContext, ClrSilver);
        GrLineDraw(psContext, 10, ui32Idx, 320, ui32Idx);
    }

    // axis line values

    char buffer[20];

    // Draw Axis Labels
    GrContextFontSet(psContext, &g_sFontCm12);
    GrContextForegroundSet(psContext, ClrBlack);

    sprintf(buffer, "%.2f", (float)(__X_MIN__));
    GrStringDraw(psContext, buffer, -1, 8, 188, 0); // Assuming y = 200 is below the x-axis

    sprintf(buffer, "%.2f", (float)((3.0*__X_MIN__ + __X_MAX__)/4.0));
    GrStringDraw(psContext, buffer, -1, 82, 188, 0); // Adjust text placement as needed

    sprintf(buffer, "%.2f", (float)((__X_MIN__ + __X_MAX__)/2.0));
    GrStringDraw(psContext, buffer, -1, 156, 188, 0); // Adjust text placement as needed

    sprintf(buffer, "%.2f", (float)((__X_MIN__ + 3.0*__X_MAX__)/4.0));
    GrStringDraw(psContext, buffer, -1, 233, 188, 0); // Adjust text placement as needed

    sprintf(buffer, "%.2f", (float)(__X_MAX__));
    GrStringDraw(psContext, buffer, -1, 310, 188, 0); // Adjust text placement as needed

    sprintf(buffer, "%.2f", (float)(__Y_MIN__));
    GrStringDraw(psContext, buffer, -1, 0, 180, 0); // Adjust text placement as needed

    sprintf(buffer, "%.2f", (float)((3.0*__Y_MIN__ + __Y_MAX__)/4.0));
    GrStringDraw(psContext, buffer, -1, 3, 135, 0); // Adjust text placement as needed

    sprintf(buffer, "%.2f", (float)((__Y_MIN__ + __Y_MAX__)/2.0));
    GrStringDraw(psContext, buffer, -1, 2, 90, 0); // Adjust text placement as needed

    sprintf(buffer, "%.2f", (float)((__Y_MIN__ + 3.0*__Y_MAX__)/4.0));
    GrStringDraw(psContext, buffer, -1, 2, 45, 0); // Adjust text placement as needed

    sprintf(buffer, "%.2f", (float)(__Y_MAX__));
    GrStringDraw(psContext, buffer, -1, 2, 0, 0); // Adjust text placement as needed



    switch(calculus) {
    case 0: {
        // thick graph
        // Draw equation with thicker lines by drawing multiple slightly offset lines
        for (ui32Idx = 1; ui32Idx < (sizeof(__MAPPED_XY__[0]) / sizeof(__MAPPED_XY__[0][0])); ui32Idx++)
        {
            // Set color for drawing the lines
            GrContextForegroundSet(psContext, ClrRed);

            // Draw multiple lines to simulate a thicker line
            int xOffset = 1;  // Offset by 1 pixel on each side
            int yOffset = 1;  // Offset by 1 pixel on each side
            int dx = -xOffset;
            int dy = -yOffset;
            for (dx = -xOffset; dx <= xOffset; dx++) {
                for (dy = -yOffset; dy <= yOffset; dy++) {
                    if(isnan(__MAPPED_XY__[1][ui32Idx - 1]) || isnan(__MAPPED_XY__[1][ui32Idx])) {
                        if(isnan(__MAPPED_XY__[1][ui32Idx - 1]) && !isnan(__MAPPED_XY__[1][ui32Idx])) {
                            GrCircleFill(psContext, __MAPPED_XY__[0][ui32Idx], __MAPPED_XY__[1][ui32Idx], 3);
                            continue;
                        } else if(!isnan(__MAPPED_XY__[1][ui32Idx - 1]) && isnan(__MAPPED_XY__[1][ui32Idx])) {
                            GrCircleFill(psContext, __MAPPED_XY__[0][ui32Idx-1], __MAPPED_XY__[1][ui32Idx-1], 3);
                            continue;
                        }
                        continue;
                    }
                    GrLineDraw(psContext,
                               ceil((int)(__MAPPED_XY__[0][ui32Idx - 1])) + dx,
                               round((int)(__MAPPED_XY__[1][ui32Idx - 1])) + dy,
                               ceil((int)(__MAPPED_XY__[0][ui32Idx])) + dx,
                               round((int)(__MAPPED_XY__[1][ui32Idx])) + dy);
                }
            }
        }
        break;}
    case 1:{
        // thick graph
        // Draw equation with thicker lines by drawing multiple slightly offset lines
        for (ui32Idx = 1; ui32Idx < (sizeof(__MAPPED_DY_DX__[0]) / sizeof(__MAPPED_DY_DX__[0][0])); ui32Idx++)
        {
            // Set color for drawing the lines
            GrContextForegroundSet(psContext, ClrRed);

            // Draw multiple lines to simulate a thicker line
            int xOffset = 1;  // Offset by 1 pixel on each side
            int yOffset = 1;  // Offset by 1 pixel on each side
            int dx = -xOffset;
            int dy = -yOffset;
            for (dx = -xOffset; dx <= xOffset; dx++) {
                for (dy = -yOffset; dy <= yOffset; dy++) {
                    if(isnan(__MAPPED_DY_DX__[1][ui32Idx - 1]) || isnan(__MAPPED_DY_DX__[1][ui32Idx])) {
                        if(isnan(__MAPPED_DY_DX__[1][ui32Idx - 1]) && !isnan(__MAPPED_DY_DX__[1][ui32Idx])) {
                            GrCircleFill(psContext, __MAPPED_DY_DX__[0][ui32Idx], __MAPPED_DY_DX__[1][ui32Idx], 3);
                            continue;
                        } else if(!isnan(__MAPPED_DY_DX__[1][ui32Idx - 1]) && isnan(__MAPPED_DY_DX__[1][ui32Idx])) {
                            GrCircleFill(psContext, __MAPPED_DY_DX__[0][ui32Idx-1], __MAPPED_DY_DX__[1][ui32Idx-1], 3);
                            continue;
                        }
                        continue;
                    }
                    GrLineDraw(psContext,
                               ceil((int)(__MAPPED_DY_DX__[0][ui32Idx - 1])) + dx,
                               round((int)(__MAPPED_DY_DX__[1][ui32Idx - 1])) + dy,
                               ceil((int)(__MAPPED_DY_DX__[0][ui32Idx])) + dx,
                               round((int)(__MAPPED_DY_DX__[1][ui32Idx])) + dy);
                }
            }
        }
        break;}
    case 2:{
        // thick graph
        // Draw equation with thicker lines by drawing multiple slightly offset lines
        for (ui32Idx = 1; ui32Idx < (sizeof(__MAPPED_INTEGRAL_XY__[0]) / sizeof(__MAPPED_INTEGRAL_XY__[0][0])); ui32Idx++)
        {
            // Set color for drawing the lines
            GrContextForegroundSet(psContext, ClrRed);

            // Draw multiple lines to simulate a thicker line
            int xOffset = 1;  // Offset by 1 pixel on each side
            int yOffset = 1;  // Offset by 1 pixel on each side
            int dx = -xOffset;
            int dy = -yOffset;
            for (dx = -xOffset; dx <= xOffset; dx++) {
                for (dy = -yOffset; dy <= yOffset; dy++) {
                    if(isnan(__MAPPED_INTEGRAL_XY__[1][ui32Idx - 1]) || isnan(__MAPPED_INTEGRAL_XY__[1][ui32Idx])) {
                        if(isnan(__MAPPED_INTEGRAL_XY__[1][ui32Idx - 1]) && !isnan(__MAPPED_INTEGRAL_XY__[1][ui32Idx])) {
                            GrCircleFill(psContext, __MAPPED_INTEGRAL_XY__[0][ui32Idx], __MAPPED_INTEGRAL_XY__[1][ui32Idx], 3);
                            continue;
                        } else if(!isnan(__MAPPED_INTEGRAL_XY__[1][ui32Idx - 1]) && isnan(__MAPPED_INTEGRAL_XY__[1][ui32Idx])) {
                            GrCircleFill(psContext, __MAPPED_INTEGRAL_XY__[0][ui32Idx-1], __MAPPED_INTEGRAL_XY__[1][ui32Idx-1], 3);
                            continue;
                        }
                        continue;
                    }
                    GrLineDraw(psContext,
                               ceil((int)(__MAPPED_INTEGRAL_XY__[0][ui32Idx - 1])) + dx,
                               round((int)(__MAPPED_INTEGRAL_XY__[1][ui32Idx - 1])) + dy,
                               ceil((int)(__MAPPED_INTEGRAL_XY__[0][ui32Idx])) + dx,
                               round((int)(__MAPPED_INTEGRAL_XY__[1][ui32Idx])) + dy);
                }
            }
        }
        break;}
    case 3:{
        // thick graph
        // Draw equation with thicker lines by drawing multiple slightly offset lines
        for (ui32Idx = 1; ui32Idx < (sizeof(__MAPPED_XY__[0]) / sizeof(__MAPPED_XY__[0][0])); ui32Idx++)
        {
            // Set color for drawing the lines
            GrContextForegroundSet(psContext, ClrRed);

            // Draw multiple lines to simulate a thicker line
            int xOffset = 1;  // Offset by 1 pixel on each side
            int yOffset = 1;  // Offset by 1 pixel on each side
            int dx = -xOffset;
            int dy = -yOffset;
            for (dx = -xOffset; dx <= xOffset; dx++) {
                for (dy = -yOffset; dy <= yOffset; dy++) {
                    if(isnan(__MAPPED_XY__[1][ui32Idx - 1]) || isnan(__MAPPED_XY__[1][ui32Idx])) {
                        if(isnan(__MAPPED_XY__[1][ui32Idx - 1]) && !isnan(__MAPPED_XY__[1][ui32Idx])) {
                            GrCircleFill(psContext, __MAPPED_XY__[0][ui32Idx], __MAPPED_XY__[1][ui32Idx], 3);
                            continue;
                        } else if(!isnan(__MAPPED_XY__[1][ui32Idx - 1]) && isnan(__MAPPED_XY__[1][ui32Idx])) {
                            GrCircleFill(psContext, __MAPPED_XY__[0][ui32Idx-1], __MAPPED_XY__[1][ui32Idx-1], 3);
                            continue;
                        }
                        continue;
                    }
                    GrLineDraw(psContext,
                               ceil((int)(__MAPPED_XY__[0][ui32Idx - 1])) + dx,
                               round((int)(__MAPPED_XY__[1][ui32Idx - 1])) + dy,
                               ceil((int)(__MAPPED_XY__[0][ui32Idx])) + dx,
                               round((int)(__MAPPED_XY__[1][ui32Idx])) + dy);
                }
            }
        }

        // plot zeros
        int i,cnt_roots = 0;
        for (i = 0; i <= __MAPPED_ZEROS__.top; i++) {
            // Fetch the coordinates from your __MAPPED_ZEROS__ array
            if(__MAPPED_ZEROS__.items[i] == 0.0) {
                cnt_roots++;
                continue;

            }

            int x_center = (int)(__MAPPED_ZEROS__.items[i]);
            int y_center = (int)(__MP_Y1__ - ((__MP_Y2__-__MP_Y1__)/(__Y_MAX__-__Y_MIN__)) * __Y_MIN__);

            // Set color for drawing the rectangles
            GrContextForegroundSet(psContext, ClrBlue);  // Assuming green color for the rectangles

            // Draw the circle
            GrCircleFill(psContext, x_center, y_center, 5);

            GrContextFontSet(psContext, &g_sFontCm14);
            if (isTextVisible) {
                sprintf(buffer, "%.2f", (float)__ZEROS__.items[i]);
                GrStringDraw(psContext, buffer, -1, x_center, y_center-20, 1);
            }
        }

        if(cnt_roots) {
            GrContextFontSet(psContext, &g_sFontCm14);
            if (isTextVisible) {
                GrContextForegroundSet(psContext, ClrBlue);
                sprintf(buffer, "%.2f", (float)__ZEROS__.items[i]);
                GrStringDraw(psContext, "No Roots Present", -1, (__X_MAX__-__X_MIN__)/2, (__Y_MAX__-__Y_MIN__)/2, 1);
            }
        }

        break;}
    case 4: {
        // thick graph
        // Draw equation with thicker lines by drawing multiple slightly offset lines
        for (ui32Idx = 1; ui32Idx < (sizeof(__MAPPED_XY__[0]) / sizeof(__MAPPED_XY__[0][0])); ui32Idx++)
        {
            // Set color for drawing the lines
            GrContextForegroundSet(psContext, ClrRed);

            // Draw multiple lines to simulate a thicker line
            int xOffset = 1;  // Offset by 1 pixel on each side
            int yOffset = 1;  // Offset by 1 pixel on each side
            int dx = -xOffset;
            int dy = -yOffset;
            for (dx = -xOffset; dx <= xOffset; dx++) {
                for (dy = -yOffset; dy <= yOffset; dy++) {
                    if(isnan(__MAPPED_XY__[1][ui32Idx - 1]) || isnan(__MAPPED_XY__[1][ui32Idx])) {
                        if(isnan(__MAPPED_XY__[1][ui32Idx - 1]) && !isnan(__MAPPED_XY__[1][ui32Idx])) {
                            GrCircleFill(psContext, __MAPPED_XY__[0][ui32Idx], __MAPPED_XY__[1][ui32Idx], 3);
                            continue;
                        } else if(!isnan(__MAPPED_XY__[1][ui32Idx - 1]) && isnan(__MAPPED_XY__[1][ui32Idx])) {
                            GrCircleFill(psContext, __MAPPED_XY__[0][ui32Idx-1], __MAPPED_XY__[1][ui32Idx-1], 3);
                            continue;
                        }
                        continue;
                    }
                    GrLineDraw(psContext,
                               ceil((int)(__MAPPED_XY__[0][ui32Idx - 1])) + dx,
                               round((int)(__MAPPED_XY__[1][ui32Idx - 1])) + dy,
                               ceil((int)(__MAPPED_XY__[0][ui32Idx])) + dx,
                               round((int)(__MAPPED_XY__[1][ui32Idx])) + dy);
                }
            }
        }
            GrContextFontSet(psContext, &g_sFontCm14);
            if (isTextVisible) {
                GrContextForegroundSet(psContext, ClrBlue);
                sprintf(buffer, "Area = %.2f", __AREA__);
                GrStringDraw(psContext, buffer, -1, (__X_MAX__-__X_MIN__)/2, (__Y_MAX__-__Y_MIN__)/2, 1);
            }
        break;}
    case 5:{
        // thick graph
        // Draw equation with thicker lines by drawing multiple slightly offset lines
        for (ui32Idx = 1; ui32Idx < (sizeof(__MAPPED_XY__[0]) / sizeof(__MAPPED_XY__[0][0])); ui32Idx++)
        {
            // Set color for drawing the lines
            GrContextForegroundSet(psContext, ClrRed);

            // Draw multiple lines to simulate a thicker line
            int xOffset = 1;  // Offset by 1 pixel on each side
            int yOffset = 1;  // Offset by 1 pixel on each side
            int dx = -xOffset;
            int dy = -yOffset;
            for (dx = -xOffset; dx <= xOffset; dx++) {
                for (dy = -yOffset; dy <= yOffset; dy++) {
                    if(isnan(__MAPPED_XY__[1][ui32Idx - 1]) || isnan(__MAPPED_XY__[1][ui32Idx])) {
                        if(isnan(__MAPPED_XY__[1][ui32Idx - 1]) && !isnan(__MAPPED_XY__[1][ui32Idx])) {
                            GrCircleFill(psContext, __MAPPED_XY__[0][ui32Idx], __MAPPED_XY__[1][ui32Idx], 3);
                            continue;
                        } else if(!isnan(__MAPPED_XY__[1][ui32Idx - 1]) && isnan(__MAPPED_XY__[1][ui32Idx])) {
                            GrCircleFill(psContext, __MAPPED_XY__[0][ui32Idx-1], __MAPPED_XY__[1][ui32Idx-1], 3);
                            continue;
                        }
                        continue;
                    }
                    GrLineDraw(psContext,
                               ceil((int)(__MAPPED_XY__[0][ui32Idx - 1])) + dx,
                               round((int)(__MAPPED_XY__[1][ui32Idx - 1])) + dy,
                               ceil((int)(__MAPPED_XY__[0][ui32Idx])) + dx,
                               round((int)(__MAPPED_XY__[1][ui32Idx])) + dy);
                }
            }
        }

        // plot maximas and minimas
        int i,cnt_max_min = 0;
        for (i = 0; i <= MAX_MAXIMA_MINIMA; i++) {
            // Fetch the coordinates from your __MAPPED_ZEROS__ array
            if(isnan(__MAPPED_MAXIMA_MINIMA__[1][i])) {
                break;
            } else {
                cnt_max_min++;
            }
        }

        for(i = 0; i <= cnt_max_min; i++) {

            int x_point = (int)(__MAPPED_MAXIMA_MINIMA__[0][i]);
            int y_point = (int)(__MAPPED_MAXIMA_MINIMA__[1][i]);

            // Set color for drawing the rectangles
            GrContextForegroundSet(psContext, ClrYellow);  // Assuming green color for the rectangles

            // Draw the circle
            GrCircleFill(psContext, x_point, y_point, 5);

            GrContextFontSet(psContext, &g_sFontCm14);
            if (isTextVisible) {
                sprintf(buffer, "(%.2f, %.2f)", (float)__MAXIMA_MINIMA__[0][i],(float)__MAXIMA_MINIMA__[1][i]);
                GrStringDraw(psContext, buffer, -1, x_point, y_point-20, 1);
            }
        }

        if(!cnt_max_min) {
            GrContextFontSet(psContext, &g_sFontCm14);
            if (isTextVisible) {
                GrContextForegroundSet(psContext, ClrBlue);
                sprintf(buffer, "%.2f", (float)__ZEROS__.items[i]);
                GrStringDraw(psContext, "No Maxima and Minima exists", -1, (__X_MAX__-__X_MIN__)/2, (__Y_MAX__-__Y_MIN__)/2, 1);
            }
        }

        break;}
    default:
        return;
    }
}
