
#include "Initial_1.h"
#include"all_functions.h"


///////fuction declaration
void deg_function(void);
void trig_function(void);

//*****************************************************************************
//
// Handles press notifications for the push button widgets.
//
//*****************************************************************************
void
OnButtonPress_2(tWidget *psWidget)
{
    uint32_t button_2;
    int pi_var=0;//index adding the pi value to the array

    //
    // Find the index of this push button.
    //
    for(button_2 = 0; button_2 < NUM_PUSH_BUTTONS_2; button_2++)
    {
        if(psWidget == (tWidget *)(g_psPushButtons_2 + button_2))
        {
            break;
        }
    }

    //
    // Return if the push button could not be found.
    //
    if(button_2 == NUM_PUSH_BUTTONS_2)
    {
        return;
    }
    switch(button_2)
        {

        case 0 :
            disp_array[disp_in]='1';
            disp_in++;
            char_pressed[index] = '1';
            index++;
            break;
        case 1 :
            disp_array[disp_in]='2';
            disp_in++;
            char_pressed[index] = '2';
            index++;
            break;
        case 2 :
            disp_array[disp_in]='3';
            disp_in++;
            char_pressed[index] = '3';
            index++;
            break;

        case 3 :
            disp_array[disp_in]='4';
            disp_in++;
            char_pressed[index] = '4';
            index++;
            break;
        case 4 :
            disp_array[disp_in]='5';
            disp_in++;
            char_pressed[index] = '5';
            index++;
            break;

        case 5 :
            disp_array[disp_in]='6';
            disp_in++;
            char_pressed[index]= '6';
            index++;
            break;
        case 6 :
            disp_array[disp_in]='7';
            disp_in++;
            char_pressed[index] = '7';
            index++;
            break;
        case 7 :
            disp_array[disp_in]='8';
            disp_in++;
            char_pressed[index] = '8';
            index++;
            break;
        case 8 :
            disp_array[disp_in]='9';
            disp_in++;
            char_pressed[index] = '9';
            index++;
            break;
        case 9 :
            disp_array[disp_in]='0';
            disp_in++;
            char_pressed[index] = '0';
            index++;
            break;

        case 10 :
            disp_array[disp_in]='.';
            disp_in++;
            char_pressed[index] = '.';
            index++;
            break;

        case 11 :
            memset(char_pressed,0,sizeof(char_pressed));
           memset(disp_array,0,sizeof(disp_array));
           memset(operators,0,sizeof(operators));
           memset(operand,0,sizeof(operand));
           memset(operand_array,0,sizeof(operand_array));
           memset(result,0,sizeof(result));
           disp_in=0;
           index=0;
           CanvasTextSet(&g_sCanvas_22, result);
            WidgetPaint((tWidget *)&g_sCanvas_22);
          // array_in=0;
            break;
        case 12 :
            index--;
            char_pressed[index] = 0;
            disp_in--;
            disp_array[disp_in]=0;
            break;
        case 13 :
            disp_array[disp_in]='(';
            disp_in++;
            char_pressed[index] = '(';
            index++;
            break;
        case 14 :
            disp_array[disp_in]=')';
            disp_in++;
            char_pressed[index] = ')';
            index++;
            break;
        case 15 ://=
           processing();
           calculation();
           display_result_2();
            break;
        case 16 ://sin
            result_update();
            processing();
            function_index=0;
            trig_function();
            break;
        case 17 ://cos
            processing();
            function_index=1;
            trig_function();
            break;
        case 18 ://Tan
            processing();
            function_index=2;
            trig_function();
            break;
        case 19 ://sinI
            processing();
            function_index=3;
            trig_function();
            break;
        case 20 ://cosI
            processing();
            function_index=4;
            trig_function();
            break;
        case 21://TanI
            processing();
            function_index=5;
            trig_function();
            break;
        case 22 ://sinh
            processing();
            function_index=6;
            trig_function();
            break;
        case 23 ://cosh
            processing();
            function_index=7;
            trig_function();
            break;
        case 24 ://tanh
            processing();
            function_index=8;
            trig_function();
            break;

        case 25 ://pi
            while(pi_char[pi_var]!=0){
                disp_array[disp_in]=pi_char[pi_var];
                disp_in++;
                char_pressed[index] = pi_char[pi_var];
                index++;
                pi_var++;
            }
            pi_var=0;
            break;
        case 26 ://Deg
            deg_function();
            break;
        case 27 :
            result_update();
            disp_array[disp_in]='+';
            disp_in++;
            char_pressed[index] = '+';
            index++;
            break;
        case 28 :
            result_update();
            disp_array[disp_in]='-';
            disp_in++;
            char_pressed[index] = '-';
            index++;
            break;
        case 29 :
            result_update();
            disp_array[disp_in]='x';
            disp_in++;
            char_pressed[index] = 'x';
            index++;
            break;
        case 30 :
            result_update();
            disp_array[disp_in]='/';
            disp_in++;
            char_pressed[index] = '/';
            index++;
            break;
        default :
            return;
           // break;

        }

        CanvasTextSet(&g_sCanvas_12, disp_array);
        WidgetPaint((tWidget *)&g_sCanvas_12);



}

void deg_function(void){
    deg_colour=deg_colour^1;
    if(deg_colour){
        PushButtonFillColorSet((g_psPushButtons_2+26),ClrDarkGreen);
    }
    else{
        PushButtonFillColorSet((g_psPushButtons_2+26),ClrMidnightBlue);
    }
}
void trig_function(){
    int n=0;
    while(operators[n]!=0){
        n++;
    }
    if(n==1 && operand_array[0]==0){//checking for single varible negative or positive numbers
        single_num=1;
        calculation();
    }
     int m=0;
     while(operand_array[m]!=0){
         length++;
         m++;
     }

     switch(function_index){
     case 0 :
         if(deg_colour){//change the degree to radians
             operand_array[length-1]=((operand_array[length-1]*3.141592)/180);
         }
             tirg_result=sinf(operand_array[length-1]); //find sin value
             break;
     case 1 :
             if(deg_colour){//change the degree to radians
                     operand_array[length-1]=((operand_array[length-1]*3.141592)/180);
                 }
            tirg_result=cosf(operand_array[length-1]); //find sin value
                  break;
     case 2 :
             if(deg_colour){//change the degree to radians
                     operand_array[length-1]=((operand_array[length-1]*3.141592)/180);
                 }
             check_var=(int )fmodf(operand_array[length-1],1.570796);
             if(check_var==0){
                 memset(result,0,sizeof(result));
                 Display("Inf");
                 CanvasTextSet(&g_sCanvas_22, result);
                 WidgetPaint((tWidget *)&g_sCanvas_22);
                  return;
             }
             tirg_result=tanf(operand_array[length-1]);
                  break;
     case 3 :
                 if(-1<=operand_array[length-1] && operand_array[length-1]<=1){
                     tirg_result=asinf(operand_array[length-1]); //find sin value
                     if(deg_colour){//change the radians to degree
                         tirg_result=((tirg_result*180)/3.141592);
                       }
                 }
                 else{
                     memset(result,0,sizeof(result));
                     Display("Out of range");
                     CanvasTextSet(&g_sCanvas_22, result);
                     WidgetPaint((tWidget *)&g_sCanvas_22);
                      return;
                 }

                  break;
     case 4 :
                     if(-1<=operand_array[length-1] && operand_array[length-1]<=1){
                             tirg_result=acosf(operand_array[length-1]); //find cos value
                             if(deg_colour){//change the radians to degree
                                 tirg_result=((tirg_result*180)/3.141592);
                               }
                         }
                         else{
                             memset(result,0,sizeof(result));
                             Display("Out of range");
                             CanvasTextSet(&g_sCanvas_22, result);
                             WidgetPaint((tWidget *)&g_sCanvas_22);
                              return;
                         }

                  break;
     case 5 :
                  tirg_result=atanf(operand_array[length-1]); //find sin value
                  if(deg_colour){//change the radians to degree
                      tirg_result=((tirg_result*180)/3.141592);
                    }
                  break;
     case 6 :
                  tirg_result=sinhf(operand_array[length-1]);
                  break;
     case 7 :
                  tirg_result=coshf(operand_array[length-1]);
                  break;
     case 8 :
                  tirg_result=tanhf(operand_array[length-1]);
                  break;
     default:
                 return;
                 //break;
     }

     float d=tirg_result;
     if(tirg_result<0){
         float c=(0-tirg_result);
         ftoa(c,temp,4); //float to char to find lenght
     }
     else{
         ftoa(tirg_result,temp,4); //float to char to find lenght
     }


    int i=0,k=0;
    int j=disp_in-1;
    index=index-1;

    while(index!=0){
        if(char_pressed[index-1]=='+'||char_pressed[index-1]=='-'||char_pressed[index-1]=='x'||char_pressed[index-1]=='/'){
            break;
        }

        index--;
    }
    while(temp[i]!=0){
        if(d<0){
            char_pressed[index]='-';
            d=0-d;
            index++;
        }
        else{
            char_pressed[index]=temp[i];
                    i++;
                    index++;
        }


    }

    memset(temp,0,sizeof(temp));
    i=0;
    while(j>=0){
        temp[i]=disp_array[j];
        i++;
        if(single_num){
            single_num=0;
        }
        else if(disp_array[j-1]=='+'||disp_array[j-1]=='-'||disp_array[j-1]=='x'||disp_array[j-1]=='/'){//-,1
           break;
        }

        j--;
    }

    if(j<0){
        j=0;
    }

    switch(function_index){
         case 0 :
             disp_array[j]='S';j++;disp_array[j]='i';j++;disp_array[j]='n';j++;disp_array[j]='(';j++;
                 break;
         case 1 :
             disp_array[j]='C';j++;disp_array[j]='o';j++;disp_array[j]='s';j++;disp_array[j]='(';j++;
                      break;
         case 2 :
             disp_array[j]='T';j++;disp_array[j]='a';j++;disp_array[j]='n';j++;disp_array[j]='(';j++;
                      break;
         case 3 :
             disp_array[j]='S';j++;disp_array[j]='i';j++;disp_array[j]='n';j++;disp_array[j]='I';j++;disp_array[j]='(';j++;
                      break;
         case 4 :
             disp_array[j]='C';j++;disp_array[j]='o';j++;disp_array[j]='s';j++;disp_array[j]='I';j++;disp_array[j]='(';j++;
                      break;
         case 5 :
             disp_array[j]='T';j++;disp_array[j]='a';j++;disp_array[j]='n';j++;disp_array[j]='I';j++;disp_array[j]='(';j++;
                      break;
         case 6 :
             disp_array[j]='S';j++;disp_array[j]='i';j++;disp_array[j]='n';j++;disp_array[j]='h';j++;disp_array[j]='(';j++;
                      break;
         case 7 :
             disp_array[j]='C';j++;disp_array[j]='o';j++;disp_array[j]='s';j++;disp_array[j]='h';j++;disp_array[j]='(';j++;
                      break;
         case 8 :
             disp_array[j]='T';j++;disp_array[j]='a';j++;disp_array[j]='n';j++;disp_array[j]='h';j++;disp_array[j]='(';j++;
                      break;
         default:
                     return;
                     //break;
         }

    while(temp[k]!=0){//1,-
        disp_array[j]=temp[i-1];
        i--;
        j++;
        k++;
    }
    disp_array[j]=')';
    disp_in=j+1;
    memset(temp,0,sizeof(temp));

    operand_array[length-1]=tirg_result;

    if(tirg_result<0){
        result[0]='-';
        float b=(0-tirg_result);
        ftoa(b, &result[1], 4);
        CanvasTextSet(&g_sCanvas_22, result);
        WidgetPaint((tWidget *)&g_sCanvas_22);
    }
    else {
        ftoa(tirg_result, result, 4);
        CanvasTextSet(&g_sCanvas_22, result);
        WidgetPaint((tWidget *)&g_sCanvas_22);
    }
    length=0;
    m=0;
}

void display_result_2(void){
    if(operand_array[0]<0){
        result[0]='-';
        float a=(0-operand_array[0]);
        ftoa(a, &result[1], 4);
        CanvasTextSet(&g_sCanvas_22, result);
        WidgetPaint((tWidget *)&g_sCanvas_22);
    }
    else if(operand_array[0]>0){
        ftoa(operand_array[0], result, 4);
        CanvasTextSet(&g_sCanvas_22, result);
        WidgetPaint((tWidget *)&g_sCanvas_22);
    }
    else{
        CanvasTextSet(&g_sCanvas_22, result);
                WidgetPaint((tWidget *)&g_sCanvas_22);
    }


}

