
#include "Initial_1.h"
#include"all_functions.h"
//#include"Home_panel.h"
//#include"Panels.h"


//*****************************************************************************
//
// Handles presses of the next panel button.
//
//*****************************************************************************
void OnNext(tWidget *psWidget)
{
    //
    // There is nothing to be done if the last panel is already being
    // displayed.
    //
    if(g_ui32Panel == (NUM_PANELS - 1))
    {
        return;
    }

    //
    // Remove the current panel.
    //
    WidgetRemove((tWidget *)(g_psPanels));

    //
    // Increment the panel index.
    //
    //g_ui32Panel++;
    uint32_t ui32Idx;

       //
       // Find the index of this push button.
       //
       for(ui32Idx = 0; ui32Idx < Home_buttons; ui32Idx++)
       {
           if(psWidget == (tWidget *)(g_psPushButtons_home + ui32Idx))
           {
               break;
           }
       }

       //
       // Return if the push button could not be found.
       //
       if(ui32Idx == Home_buttons)
       {
           return;
       }
       switch(ui32Idx)
       {

       case 0 :
           WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 1));
           WidgetPaint((tWidget *)(g_psPanels + 1));
           g_ui32Panel=1;
           break;
       case 1 :
           WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 2));
            WidgetPaint((tWidget *)(g_psPanels + 2));
            g_ui32Panel=2;
           break;
       case 2 :
              WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 3));
               WidgetPaint((tWidget *)(g_psPanels + 3));
               g_ui32Panel=3;
              break;
//       case 3 :
//              WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 4));
//               WidgetPaint((tWidget *)(g_psPanels + 4));
//               g_ui32Panel=4;
//              break;
//       case 4 :
//              WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 5));
//               WidgetPaint((tWidget *)(g_psPanels + 5));
//               g_ui32Panel=5;
//              break;
       case 3 :
                WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 6));
                 WidgetPaint((tWidget *)(g_psPanels + 6));
                 g_ui32Panel=6;
                break;
       case 6 :
                WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
                WidgetPaint((tWidget *)(g_psPanels + 7));
                g_ui32Panel=7;
                break;
       default :
           return;

       }

    // Add and draw the new panel.
    //

       g_ui32ButtonState_home ^= 1 << ui32Idx;

    // See if the previous panel was the first panel.
    //
    if(g_ui32Panel >= 1)
    {
        //
        // Display the previous button.
        //
        PushButtonFillOn(&g_sPrevious);
        PushButtonTextOn(&g_sPrevious);
        PushButtonFillOff(&g_sPrevious);
        WidgetPaint((tWidget *)&g_sPrevious);
    }



}
