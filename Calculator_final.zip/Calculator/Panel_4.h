
#ifndef PANEL_4_H_
#define PANEL_4_H_

#include "Initial_1.h"
#include"all_functions.h"

//*****************************************************************************
//
// The fourth panel, which contains age calculator.
//
//*****************************************************************************
Canvas(g_sCanvas_64, g_psPanels+4, 0, 0,
       &g_sKentec320x240x16_SSD2119, 120, 68, 200, 40,
       CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT,
       ClrMidnightBlue, ClrGray, ClrSilver, &g_sFontCm22, "", 0, 0);
//for the expression
Canvas(g_sCanvas_54, g_psPanels+4,&g_sCanvas_64 , 0,
       &g_sKentec320x240x16_SSD2119, 0, 68, 120, 40,
       CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT,
       ClrMidnightBlue, ClrGray, ClrSilver, &g_sFontCm22, "eq enter", 0, 0);
Canvas(g_sCanvas_44, g_psPanels+4, &g_sCanvas_54, 0,
       &g_sKentec320x240x16_SSD2119, 120, 33, 200, 33,
       CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT,
       ClrMidnightBlue, ClrGray, ClrSilver, &g_sFontCm22, "a,b,c", 0, 0);
//for the expression
Canvas(g_sCanvas_34, g_psPanels+4,&g_sCanvas_44 , 0,
       &g_sKentec320x240x16_SSD2119, 0, 33, 120, 33,
       CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT,
       ClrMidnightBlue, ClrGray, ClrSilver, &g_sFontCm18, "input format", 0, 0);
Canvas(g_sCanvas_24, g_psPanels+4, &g_sCanvas_34, 0,
       &g_sKentec320x240x16_SSD2119, 120, 0, 200, 33,
       CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT,
       ClrMidnightBlue, ClrGray, ClrSilver, &g_sFontCm22, "ax^2+bx+c", 0, 0);
//for the expression
Canvas(g_sCanvas_14, g_psPanels+4,&g_sCanvas_24 , 0,
       &g_sKentec320x240x16_SSD2119, 0, 0, 120, 33,
       CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT,
       ClrMidnightBlue, ClrGray, ClrSilver, &g_sFontCm22, "Equation", 0, 0);


tPushButtonWidget g_psPushButtons_4[] =
{

 RectangularButtonStruct(g_psPanels+4, g_psPushButtons_4 + 1, 0, &g_sKentec320x240x16_SSD2119, 0, 112, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
                          &g_sFontCm22, "1", 0, 0, 0, 0, OnButtonPress_4),

//RectangularButtonStruct(g_psPanels+4, g_psPushButtons_4 + 2, 0,&g_sKentec320x240x16_SSD2119, 40 , 112, 40, 40, PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
//                         &g_sFontCm22, "2", 0, 0, 0, 0, OnButtonPress_4),
//
//RectangularButtonStruct(g_psPanels+4 , g_psPushButtons_4 + 3, 0, &g_sKentec320x240x16_SSD2119, 80 , 112, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
//                     &g_sFontCm22, "3", 0, 0, 0, 0, OnButtonPress_4),
//
// RectangularButtonStruct(g_psPanels+4, g_psPushButtons_4+4, 0,&g_sKentec320x240x16_SSD2119, 120 , 112, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
//                        &g_sFontCm22, "4", 0, 0, 0, 0, OnButtonPress_4),
//
//RectangularButtonStruct(g_psPanels+4, g_psPushButtons_4+5, 0,&g_sKentec320x240x16_SSD2119, 160 , 112, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT, ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
//                        &g_sFontCm22, "5", 0, 0, 0, 0, OnButtonPress_4),
//
// RectangularButtonStruct(g_psPanels+4, g_psPushButtons_4+6, 0, &g_sKentec320x240x16_SSD2119, 200 , 112, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
//                        &g_sFontCm22, "6", 0, 0, 0, 0, OnButtonPress_4),
//
//RectangularButtonStruct(g_psPanels+4,g_psPushButtons_4+7, 0,&g_sKentec320x240x16_SSD2119, 240 , 112, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
//                        &g_sFontCm22, "7", 0, 0, 0, 0, OnButtonPress_4),
//
//RectangularButtonStruct(g_psPanels+4,g_psPushButtons_4+8, 0,&g_sKentec320x240x16_SSD2119, 280 , 112, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
//                        &g_sFontCm22, "8", 0, 0, 0, 0, OnButtonPress_4),
//
//RectangularButtonStruct(g_psPanels+4, g_psPushButtons_4 + 9, 0, &g_sKentec320x240x16_SSD2119, 0 , 156, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
//                        &g_sFontCm22, "9", 0, 0, 0, 0, OnButtonPress_4),
//
//RectangularButtonStruct(g_psPanels+4, g_psPushButtons_4 + 10, 0,&g_sKentec320x240x16_SSD2119, 40 , 156, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
//                       &g_sFontCm22, "0", 0, 0, 0, 0, OnButtonPress_4),
//RectangularButtonStruct(g_psPanels+4, g_psPushButtons_4 + 11, 0,&g_sKentec320x240x16_SSD2119, 80 , 156, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
//                         &g_sFontCm22, ",", 0, 0, 0, 0, OnButtonPress_4),
// RectangularButtonStruct(g_psPanels+4, g_psPushButtons_4+12, 0,&g_sKentec320x240x16_SSD2119, 120 , 156, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
//                         &g_sFontCm16, "Del", 0, 0, 0, 0, OnButtonPress_4),
//RectangularButtonStruct(g_psPanels+4, g_psPushButtons_4+13, 0,&g_sKentec320x240x16_SSD2119, 160 , 156, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT, ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
//                          &g_sFontCm16, "CR", 0, 0, 0, 0, OnButtonPress_4),
//                          RectangularButtonStruct(g_psPanels+4, g_psPushButtons_4+14, 0,&g_sKentec320x240x16_SSD2119, 40 , 200, 120, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT, ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
//                                                    &g_sFontCm16, "=", 0, 0, 0, 0, OnButtonPress_4),
 RectangularButtonStruct(g_psPanels+4,&g_sCanvas_14, 0,&g_sKentec320x240x16_SSD2119, 200 , 156, 120, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrMidnightBlue, ClrBlack, ClrGray, ClrSilver,
                         &g_sFontCm22, "-", 0, 0, 0, 0, OnButtonPress_4),




};
int NUM_PUSH_BUTTONS_4 =       (sizeof(g_psPushButtons_4) / sizeof(g_psPushButtons_4[0]));
uint32_t g_ui32ButtonState_4;

#endif
