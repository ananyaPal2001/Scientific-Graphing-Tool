
#ifndef PANELS_H_
#define PANELS_H_

#include "Initial_1.h"
#include"all_functions.h"
#include"Home_panel.h"
#include"Panel_1.h"
#include"Panel_2.h"
#include"Panel_3.h"
#include"Panel_4.h"
#include"Panel_5.h"
//********** Graph Plotter Panel **********//
#include"Panel_6.h"
#include"Panel_6_2.h"


tCanvasWidget g_psPanels[] =
{
    CanvasStruct(0, 0, g_psPushButtons_home, &g_sKentec320x240x16_SSD2119, 0, 0,
                 320, 240, CANVAS_STYLE_FILL, ClrBlack, 0, 0, 0, 0, 0, 0),
   CanvasStruct(0, 0, g_psPushButtons_1, &g_sKentec320x240x16_SSD2119, 0, 0,
                              320, 240, CANVAS_STYLE_FILL, ClrBlack, 0, 0, 0, 0, 0, 0),
    CanvasStruct(0, 0, g_psPushButtons_2, &g_sKentec320x240x16_SSD2119, 0, 0,
                 320, 240, CANVAS_STYLE_FILL, ClrBlack, 0, 0, 0, 0, 0, 0),
   CanvasStruct(0, 0, g_psPushButtons_3, &g_sKentec320x240x16_SSD2119, 0, 0,
                              320, 240, CANVAS_STYLE_FILL, ClrBlack, 0, 0, 0, 0, 0, 0),
    CanvasStruct(0, 0, g_psPushButtons_4, &g_sKentec320x240x16_SSD2119, 0, 0,
                            320, 240, CANVAS_STYLE_FILL, ClrBlack, 0, 0, 0, 0, 0, 0),
    CanvasStruct(0, 0, g_psPushButtons_5, &g_sKentec320x240x16_SSD2119, 0, 0,
                          320, 240, CANVAS_STYLE_FILL, ClrBlack, 0, 0, 0, 0, 0, 0),
    //********** Graph Plotter Panel **********//
    CanvasStruct(0, 0, g_psPushButtons_6, &g_sKentec320x240x16_SSD2119, 0, 0,
                          320, 240, CANVAS_STYLE_FILL, ClrBlack, 0, 0, 0, 0, 0, 0),
    CanvasStruct(0, 0, g_psPushButtons_6_2, &g_sKentec320x240x16_SSD2119, 0, 0,
                          320, 240, CANVAS_STYLE_FILL, ClrWhite, 0, 0, 0, 0, 0, 0),
};

int NUM_PANELS=(sizeof(g_psPanels) / sizeof(g_psPanels[0]));


#endif
