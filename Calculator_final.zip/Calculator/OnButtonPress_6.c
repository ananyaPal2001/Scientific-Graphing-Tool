#include "Initial_1.h"
#include"all_functions.h"
#include "evaluate.h"

void Eval_function_6(void);

void
OnButtonPress_6(tWidget *psWidget)
{
    uint32_t button_6;

    for(button_6 = 0; button_6 < NUM_PUSH_BUTTONS_6; button_6++)
    {
        if(psWidget == (tWidget *)(g_psPushButtons_6 + button_6))
        {
            break;
        }
    }

    if(button_6 == NUM_PUSH_BUTTONS_6)
    {
        return;
    }
    switch(button_6)
    {
        case 0:
            disp_array[disp_in] = '1';
            disp_in++;
            char_pressed[index] = '1';
            index++;
            break;
        case 1:
            disp_array[disp_in] = '2';
            disp_in++;
            char_pressed[index] = '2';
            index++;
            break;
        case 2:
            disp_array[disp_in] = '3';
            disp_in++;
            char_pressed[index] = '3';
            index++;
            break;
        case 3:
            disp_array[disp_in] = '4';
            disp_in++;
            char_pressed[index] = '4';
            index++;
            break;
        case 4:
            disp_array[disp_in] = '5';
            disp_in++;
            char_pressed[index] = '5';
            index++;
            break;
        case 5:
            disp_array[disp_in] = '6';
            disp_in++;
            char_pressed[index] = '6';
            index++;
            break;
        case 6:
            disp_array[disp_in] = '7';
            disp_in++;
            char_pressed[index] = '7';
            index++;
            break;
        case 7:
            disp_array[disp_in] = '8';
            disp_in++;
            char_pressed[index] = '8';
            index++;
            break;
        case 8:
            disp_array[disp_in] = '9';
            disp_in++;
            char_pressed[index] = '9';
            index++;
            break;
        case 9:
            disp_array[disp_in] = '0';
            disp_in++;
            char_pressed[index] = '0';
            index++;
            break;
        case 10:
            disp_array[disp_in] = '.';
            disp_in++;
            char_pressed[index] = '.';
            index++;
            break;
        case 11:
            memset(char_pressed,0,sizeof(char_pressed));
            memset(disp_array,0,sizeof(disp_array));
            memset(operators,0,sizeof(operators));
            memset(operand,0,sizeof(operand));
            memset(operand_array,0,sizeof(operand_array));
            memset(result,0,sizeof(result));
            disp_in = 0;
            index = 0;
            CanvasTextSet(&g_sCanvas_26, result);
            WidgetPaint((tWidget *)&g_sCanvas_26);
            __MATH_ERR__ = 0;
            break;
        case 12:
            index--;
            if(char_pressed[index] == '(') {
                char_pressed[index--] = 0;
                char_pressed[index--] = 0;
                char_pressed[index--] = 0;
                char_pressed[index] = 0;
                disp_in--;
                disp_array[disp_in--] = 0;
                disp_array[disp_in--] = 0;
                disp_array[disp_in--] = 0;
                disp_array[disp_in] = 0;
                break;
            }
            if(char_pressed[index] == 'i') {
                char_pressed[index--] = 0;
                char_pressed[index] = 0;
                disp_in--;
                disp_array[disp_in--] = 0;
                disp_array[disp_in] = 0;
                break;
            }
            char_pressed[index] = 0;
            disp_in--;
            disp_array[disp_in] = 0;
            break;
        case 13:
            result_update();
            function_index = 5;
            Eval_function_6();
            break;
        case 14:
            result_update();
            disp_array[disp_in] = 'x';
            disp_in++;
            char_pressed[index] = 'x';
            index++;
            break;
        case 15:
            result_update();
            disp_array[disp_in] = 't';
            disp_in++;
            char_pressed[index] = 't';
            index++;
            break;
        case 16:
            result_update();
            disp_array[disp_in] = '+';
            disp_in++;
            char_pressed[index] = '+';
            index++;
            break;
        case 17:
            result_update();
            disp_array[disp_in] = '-';
            disp_in++;
            char_pressed[index] = '-';
            index++;
            break;
        case 18:
            result_update();
            disp_array[disp_in] = '*';
            disp_in++;
            char_pressed[index] = '*';
            index++;
            break;
        case 19: //sin
            result_update();
            function_index = 0;
            Eval_function_6();
            break;
        case 20: //cos
            result_update();
            function_index = 1;
            Eval_function_6();
            break;
        case 21: //tan
            result_update();
            function_index = 2;
            Eval_function_6();
            break;
        case 22:
            result_update();
            disp_array[disp_in] = '(';
            disp_in++;
            char_pressed[index] = '(';
            index++;
            break;
        case 23:
            result_update();
            disp_array[disp_in] = ')';
            disp_in++;
            char_pressed[index] = ')';
            index++;
            break;
        case 24: //pi
            result_update();
            function_index = 3;
            Eval_function_6();
            break;
        case 25:
            result_update();
            disp_array[disp_in] = '/';
            disp_in++;
            char_pressed[index] = '/';
            index++;
            break;
        case 26:
            result_update();
            disp_array[disp_in] = '^';
            disp_in++;
            char_pressed[index] = '^';
            index++;
            break;
        case 27:
            disp_array[disp_in] = 'e';
            disp_in++;
            char_pressed[index] = 'e';
            index++;
            break;
        case 28: //log
            result_update();
            function_index = 4;
            Eval_function_6();
            break;
        case 29: //plot
            display_result_6();
            break;
        default:
            return;
    }

    if(button_6 != 29) {
        CanvasTextSet(&g_sCanvas_16, disp_array);
        WidgetPaint((tWidget *)&g_sCanvas_16);
    }

    g_ui32ButtonState_6 ^= 1 << button_6;
}

void Eval_function_6(){
    switch(function_index){
        case 0 :
            disp_array[disp_in]='s';disp_in++;disp_array[disp_in]='i';disp_in++;disp_array[disp_in]='n';disp_in++;disp_array[disp_in]='(';disp_in++;
            char_pressed[index] = 's';index++;char_pressed[index] = 'i';index++;char_pressed[index] = 'n';index++;char_pressed[index] = '(';index++;
            break;
        case 1 :
            disp_array[disp_in]='c';disp_in++;disp_array[disp_in]='o';disp_in++;disp_array[disp_in]='s';disp_in++;disp_array[disp_in]='(';disp_in++;
            char_pressed[index] = 'c';index++;char_pressed[index] = 'o';index++;char_pressed[index] = 's';index++;char_pressed[index] = '(';index++;
            break;
        case 2 :
            disp_array[disp_in]='t';disp_in++;disp_array[disp_in]='a';disp_in++;disp_array[disp_in]='n';disp_in++;disp_array[disp_in]='(';disp_in++;
            char_pressed[index] = 't';index++;char_pressed[index] = 'a';index++;char_pressed[index] = 'n';index++;char_pressed[index] = '(';index++;
            break;
        case 3 :
            disp_array[disp_in]='p';disp_in++;disp_array[disp_in]='i';disp_in++;
            char_pressed[index] = 'p';index++;char_pressed[index] = 'i';index++;
            break;
        case 4 :
            disp_array[disp_in]='l';disp_in++;disp_array[disp_in]='o';disp_in++;disp_array[disp_in]='g';disp_in++;disp_array[disp_in]='(';disp_in++;
            char_pressed[index] = 'l';index++;char_pressed[index] = 'o';index++;char_pressed[index] = 'g';index++;char_pressed[index] = '(';index++;
            break;
        case 5 :
            disp_array[disp_in]='m';disp_in++;disp_array[disp_in]='o';disp_in++;disp_array[disp_in]='d';disp_in++;disp_array[disp_in]='(';disp_in++;
            char_pressed[index] = 'm';index++;char_pressed[index] = 'o';index++;char_pressed[index] = 'd';index++;char_pressed[index] = '(';index++;
        default:
            return;
    }

}

void display_result_6(void)
{
    // initialize buttons
    strcpy(btn1,"+");
    strcpy(btn2,"-");
    strcpy(btn3,"L");
    strcpy(btn4,"R");
    strcpy(btn5,"f'(x)");
    strcpy(btn6,"F(x)");
    strcpy(btn7,"1/2");
    change_btn = 0;

    initialize();                       // step 1: initialize the global variables
    strcpy(__EXPR__, char_pressed);    // step 2: change the expression
    __X_MIN__ = -10;                    // step 3: change the minimum x value
    __X_MAX__ = 10;                     // step 4: change the maximum x value
    areBracketsBalanced(__EXPR__);
    if(!__MATH_ERR__) {
        xy_vals();                          // step 5: generate x and y values
        __MP_X1__ = 10;                      // step 6.1: change the x1 value for mapping
        __MP_Y1__ = 189;                      // step 6.2: change the y1 value for mapping
        __MP_X2__ = 320;                    // step 6.3: change the x2 value for mapping
        __MP_Y2__ = 0;                    // step 6.4: change the y2 value for mapping
        map_xy();
    }
    if(__MATH_ERR__) {
        Display("MATH ERROR");
        CanvasTextSet(&g_sCanvas_26, result);
        WidgetPaint((tWidget *)&g_sCanvas_26);
        CanvasTextSet(&g_sCanvas_16, disp_array);
        WidgetPaint((tWidget *)&g_sCanvas_16);

    } else {
        WidgetRemove((tWidget *)(g_psPanels + 6));
        WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
        WidgetPaint((tWidget *)(g_psPanels + 7));
        g_ui32Panel=7;
        g_ui32ButtonState_home ^= 1 << 6;
        PushButtonFillOn(&g_sPrevious);
        PushButtonTextOn(&g_sPrevious);
        WidgetPaint((tWidget *)&g_sPrevious);
    }
}

