
#include "Initial_1.h"
#include"all_functions.h"

//functions
void bin_to_dec(void);
void dec_to_bin(void);
void dec_to_hex(void);
void hex_to_dec(void);

void OnButtonPress_3(tWidget *psWidget)
{
    uint32_t button_3;

    //
    // Find the index of this push button.
    //
    for(button_3 = 0; button_3 < NUM_PUSH_BUTTONS_3; button_3++)
    {
        if(psWidget == (tWidget *)(g_psPushButtons_3 + button_3))
        {
            break;
        }
    }

    //
    // Return if the push button could not be found.
    //
    if(button_3 == NUM_PUSH_BUTTONS_3)
    {
        return;
    }
    switch(button_3)
    {

    case 0 :
        char_pressed_3[DataConv_idx] = '1';
        DataConv_idx++;
        break;
    case 1 :
        if(DataConv_fun==1 || DataConv_fun==3||DataConv_fun==4){
            char_pressed_3[DataConv_idx] = '2';
            DataConv_idx++;
        }
        break;
    case 2 :
        if(DataConv_fun==1 || DataConv_fun==3||DataConv_fun==4){
            char_pressed_3[DataConv_idx] = '3';
            DataConv_idx++;
        }
        break;

    case 3 :
        if(DataConv_fun==1 || DataConv_fun==3||DataConv_fun==4){
            char_pressed_3[DataConv_idx] = '4';
            DataConv_idx++;
        }
        break;
    case 4 :
        if(DataConv_fun==1 || DataConv_fun==3||DataConv_fun==4){
            char_pressed_3[DataConv_idx] = '5';
            DataConv_idx++;
        }
        break;

    case 5 :
        if(DataConv_fun==1 || DataConv_fun==3||DataConv_fun==4){
            char_pressed_3[DataConv_idx]= '6';
            DataConv_idx++;
        }
        break;
    case 6 :
        if(DataConv_fun==1 || DataConv_fun==3||DataConv_fun==4){
            char_pressed_3[DataConv_idx] = '7';
            DataConv_idx++;
        }
        break;
    case 7 :
        if(DataConv_fun==1 || DataConv_fun==3||DataConv_fun==4){
            char_pressed_3[DataConv_idx] = '8';
            DataConv_idx++;
        }
        break;
    case 8 :
        if(DataConv_fun==1 || DataConv_fun==3||DataConv_fun==4){
            char_pressed_3[DataConv_idx] = '9';
            DataConv_idx++;
        }
        break;
    case 9 :
        char_pressed_3[DataConv_idx] = '0';
        DataConv_idx++;
        break;

    case 10 :
        char_pressed_3[DataConv_idx] = '.';
        DataConv_idx++;
        break;

    case 11 :
        if(DataConv_fun==4){
            char_pressed_3[DataConv_idx] = 'A';
            DataConv_idx++;
        }
        break;

    case 12 :
        if(DataConv_fun==4){
        char_pressed_3[DataConv_idx] = 'E';
        DataConv_idx++;
        }
        break;
    case 13 : //DEC_TO_BIN
         DataConv_fun=1;
         input_data_type[0] ='D';
         input_data_type[1] ='E';
         input_data_type[2] ='C';
         output_data_type[0] ='B';
         output_data_type[1] ='I';
         output_data_type[2] ='N';
         CanvasTextSet(&g_sCanvas_13, input_data_type);
         WidgetPaint((tWidget *)&g_sCanvas_13);
         CanvasTextSet(&g_sCanvas_33, output_data_type);
         WidgetPaint((tWidget *)&g_sCanvas_33);
         memset(result_3,0,sizeof(result_3));
         CanvasTextSet(&g_sCanvas_43, result_3);
         WidgetPaint((tWidget *)&g_sCanvas_43);
         memset(char_pressed_3,0,sizeof(char_pressed_3));
         DataConv_idx=0;
    case 14 : //operation '='
        switch(DataConv_fun){
        case 1:
            dec_to_bin();
            CanvasTextSet(&g_sCanvas_43, result_3);
            WidgetPaint((tWidget *)&g_sCanvas_43);
            break;
        case 2:
            bin_to_dec();
            CanvasTextSet(&g_sCanvas_43, result_3);
            WidgetPaint((tWidget *)&g_sCanvas_43);
            break;
        case 3:
            dec_to_hex();
            CanvasTextSet(&g_sCanvas_43, result_3);
            WidgetPaint((tWidget *)&g_sCanvas_43);
            break;
        case 4:
            hex_to_dec();
            CanvasTextSet(&g_sCanvas_43, result_3);
            WidgetPaint((tWidget *)&g_sCanvas_43);
            break;
        default: return;
        }

        break;
    case 15 :
        if(DataConv_fun==4){
        char_pressed_3[DataConv_idx] = 'B';
        DataConv_idx++;
        }
        break;
    case 16 :
        if(DataConv_fun==4){
        char_pressed_3[DataConv_idx] = 'F';
        DataConv_idx++;
        }
        break;
    case 17 : //BIN_TO_DEC
        DataConv_fun=2;
        input_data_type[0] ='B';
        input_data_type[1] ='I';
        input_data_type[2] ='N';
        output_data_type[0] ='D';
        output_data_type[1] ='E';
        output_data_type[2] ='C';
        CanvasTextSet(&g_sCanvas_13, input_data_type);
        WidgetPaint((tWidget *)&g_sCanvas_13);
        CanvasTextSet(&g_sCanvas_33, output_data_type);
        WidgetPaint((tWidget *)&g_sCanvas_33);
        memset(result_3,0,sizeof(result_3));
        CanvasTextSet(&g_sCanvas_43, result_3);
        WidgetPaint((tWidget *)&g_sCanvas_43);
        memset(char_pressed_3,0,sizeof(char_pressed_3));
        DataConv_idx=0;
    case 18 :
        if(DataConv_fun==4){
        char_pressed_3[DataConv_idx] = 'C';
        DataConv_idx++;
        }
        break;
    case 19 ://display clear
        memset(input_data_type,0,sizeof(input_data_type));
        memset(output_data_type,0,sizeof(output_data_type));
        CanvasTextSet(&g_sCanvas_13, input_data_type);
        WidgetPaint((tWidget *)&g_sCanvas_13);
        CanvasTextSet(&g_sCanvas_33, output_data_type);
       WidgetPaint((tWidget *)&g_sCanvas_33);
        memset(char_pressed_3,0,sizeof(char_pressed_3));
        DataConv_fun=0;
        memset(result_3,0,sizeof(result_3));
        CanvasTextSet(&g_sCanvas_43, result_3);
        WidgetPaint((tWidget *)&g_sCanvas_43);
        DataConv_idx=0;
        break;
    case 20 : //DEC_TO_HEX
        DataConv_fun=3;
        input_data_type[0] ='D';
        input_data_type[1] ='E';
        input_data_type[2] ='C';
        output_data_type[0] ='H';
        output_data_type[1] ='E';
        output_data_type[2] ='X';
        CanvasTextSet(&g_sCanvas_13, input_data_type);
        WidgetPaint((tWidget *)&g_sCanvas_13);
        CanvasTextSet(&g_sCanvas_33, output_data_type);
        WidgetPaint((tWidget *)&g_sCanvas_33);
        memset(result_3,0,sizeof(result_3));
        CanvasTextSet(&g_sCanvas_43, result_3);
        WidgetPaint((tWidget *)&g_sCanvas_43);
        memset(char_pressed_3,0,sizeof(char_pressed_3));
        DataConv_idx=0;
    case 21 :
        if(DataConv_fun==4){
            char_pressed_3[DataConv_idx] = 'D';
            DataConv_idx++;
        }
        break;
    case 22 ://backspace
        DataConv_idx--;
        char_pressed_3[DataConv_idx] = 0;
        break;
    case 23 : //HEX_TO_DEC
        DataConv_fun=4;
        input_data_type[0] ='H';
        input_data_type[1] ='E';
        input_data_type[2] ='X';
        output_data_type[0] ='D';
        output_data_type[1] ='E';
        output_data_type[2] ='C';
        CanvasTextSet(&g_sCanvas_13, input_data_type);
        WidgetPaint((tWidget *)&g_sCanvas_13);
        CanvasTextSet(&g_sCanvas_33, output_data_type);
        WidgetPaint((tWidget *)&g_sCanvas_33);
        memset(result_3,0,sizeof(result_3));
        CanvasTextSet(&g_sCanvas_43, result_3);
        WidgetPaint((tWidget *)&g_sCanvas_43);
        memset(char_pressed_3,0,sizeof(char_pressed_3));
        DataConv_idx=0;

    default :
        //DataConv_fun=0;
        return;
        //break;

    }
    CanvasTextSet(&g_sCanvas_23, char_pressed_3);
    WidgetPaint((tWidget *)&g_sCanvas_23);

}


void dec_to_bin(void){
    char integer_part[20];
    int b, k, l=0, n, i=0;
    float dec_no, a;
    dec_no=atof(char_pressed_3);
    b=dec_no;
    a=dec_no-b;
    while(b!=0){
        n=b%2;
        b/=2;
        if(n){
            integer_part[i]='1';
        }
        else integer_part[i]='0';
        i++;
    }
    for(k=i-1;k>=0;k--){
        result_3[k]=integer_part[i-1-k];
    }
    result_3[i]='.';
    i++;
    for(k=1;k<=8;k++){
        a=a*2;
        l=a;
        if(l){
            result_3[i]='1';
            a=a-l;
        }
        else
        result_3[i]='0';
        i++;

    }
}

void dec_to_hex(void){
    char integer_part[20];
    int b, k, l=0, n, i=0;
    float dec_no, a;
    dec_no=atof(char_pressed_3);
    b=dec_no;
    a=dec_no-b;
    while(b!=0){
        n=b%16;
        b=b/16;
        switch(n){
        case 10: integer_part[i]='A'; break;
        case 11: integer_part[i]='B'; break;
        case 12: integer_part[i]='C'; break;
        case 13: integer_part[i]='D'; break;
        case 14: integer_part[i]='E'; break;
        case 15: integer_part[i]='F'; break;
        default: integer_part[i]=n+48;
        }
        i++;
    }
    for(k=i-1;k>=0;k--){
        result_3[k]=integer_part[i-1-k];
    }
    result_3[i]='.';
    i++;
    for(k=1;k<=4;k++){
        a=a*16;
        l=a;
        switch(l){
        case 10: result_3[i]='A'; break;
        case 11: result_3[i]='B'; break;
        case 12: result_3[i]='C'; break;
        case 13: result_3[i]='D'; break;
        case 14: result_3[i]='E'; break;
        case 15: result_3[i]='F'; break;
        default: result_3[i]=l+48;
        }
        a = a-l;
        i++;

    }
}



void bin_to_dec(void){
    int i=0;
    float a=1;
    float dec=0;
   while(char_pressed_3[i]=='0' || char_pressed_3[i]=='1'){
        if(char_pressed_3[i]=='1'){
            dec = (dec*2)+1;
        }
        else
            dec = dec*2;
        i++;
    }
   if(char_pressed_3[i]=='.'){
        i++;
        while(char_pressed_3[i]!=0){
            a=a/2;
            if(char_pressed_3[i]=='1'){
               dec = dec + a;
            }
            i++;
        }
    }

    ftoa(dec, result_3, 4);

}

void hex_to_dec(void){
    int i=0, n;
    float a=1, dec=0;
    while(char_pressed_3[i]!=0 && char_pressed_3[i]!='.'){
        switch(char_pressed_3[i]){
        case 'A': n=10; break;
        case 'B': n=11; break;
        case 'C': n=12; break;
        case 'D': n=13; break;
        case 'E': n=14; break;
        case 'F': n=15; break;
        default: n= char_pressed_3[i]-48;
        }
        dec = (dec*16)+n;
        i++;
    }
    if(char_pressed_3[i]=='.'){
        i++;
        while(char_pressed_3[i]!=0){
            a=a/16;
            switch(char_pressed_3[i]){
            case 'A': n=10; break;
            case 'B': n=11; break;
            case 'C': n=12; break;
            case 'D': n=13; break;
            case 'E': n=14; break;
            case 'F': n=15; break;
            default: n= char_pressed_3[i]-48;
            }
//           if(char_pressed_3[i]=='1'){
               dec = dec + (a*n);
            i++;
        }
    }
    ftoa(dec, result_3, 4);
}
