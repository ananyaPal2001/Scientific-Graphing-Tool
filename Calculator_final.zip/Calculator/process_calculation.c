#include "Initial_1.h"

void processing(void){
    int i=0,oprnd_in=0,oper_in=0,array_in=0;
    while(char_pressed[i]!=0){

        if(char_pressed[i]=='+'||char_pressed[i]=='-'||char_pressed[i]=='x'||char_pressed[i]=='/'||char_pressed[i]=='^'||char_pressed[i]=='p'||char_pressed[i]=='c'){
                operand_array[array_in]=atof(operand);
                array_in++;
                memset(operand,0,sizeof(operand));
                oprnd_in=0;

            operators[oper_in]=char_pressed[i];
            oper_in++;
            i++;
        }
        else{
            operand[oprnd_in]=char_pressed[i];
            oprnd_in++;
            i++;
        }
    }
    operand_array[array_in]=atof(operand);
    memset(operand,0,sizeof(operand));
    oprnd_in=0;
    i=0;
}

void calculation(void){
    int i=0;

    while(operators[i]!=0){
        no_of_operator++;
        i++;
    }

    i=0;
    int j=0;
    while(operators[j]!=0){
        if(operators[j]=='^'||operators[j]=='p'||operators[j]=='c'){
            i=j;
            if(operators[i]=='^'){
                operand_array[i]=pow(operand_array[i],operand_array[i+1]);
                while(i<no_of_operator){
                operand_array[i+1]=operand_array[i+2];
                operators[i]=operators[i+1];
                    i++;
                }
            }
            else if(operators[i]=='p'){
                n=(int)(operand_array[i]);
                r=(int)(operand_array[i+1]);
                if(n<r||n<0||r<0){
                    Display("Math_Err");
                    return;
                }
                operand_array[i]=(factorial(n)/factorial(n-r));
                while(i<no_of_operator){
                    operand_array[i+1]=operand_array[i+2];
                    operators[i]=operators[i+1];
                    i++;
                }
            }
            else if(operators[i]=='c'){
                n=(int)(operand_array[i]);
                r=(int)(operand_array[i+1]);
                if(n<r||n<0||r<0){
                    Display("Math_Err");
                    return;
                }

                operand_array[i]=(factorial(n)/(factorial(r)*factorial(n-r)));
                while(i<no_of_operator){
                operand_array[i+1]=operand_array[i+2];
                operators[i]=operators[i+1];
                    i++;
                }
            }
            no_of_operator--;
        }
        else{
                j++;
        }
    }

    i=0;
    j=0;
    while(operators[j]!=0){
        if(operators[j]=='x'||operators[j]=='/'){
            i=j;
            if(operators[i]=='x'){
                operand_array[i]=operand_array[i]*operand_array[i+1];
                while(i<no_of_operator){
                    operand_array[i+1]=operand_array[i+2];
                    operators[i]=operators[i+1];
                    i++;
                }
            }
            else if(operators[j]=='/'){
                if(operand_array[i+1]==0){
                    Display("Math_Err");
                    return;
                }
                operand_array[i]=operand_array[i]/operand_array[i+1];
                while(i<no_of_operator){
                    operand_array[i+1]=operand_array[i+2];
                    operators[i]=operators[i+1];
                    i++;
                }

            }
            no_of_operator--;
        }
        else{
            j++;
        }
    }

    i=0;
    j=0;
    while(operators[j]!=0){
        if(operators[j]=='+'||operators[j]=='-'){
            i=j;
            if(operators[i]=='+'){
                operand_array[i]=operand_array[i]+operand_array[i+1];
                while(i<no_of_operator){
                    operand_array[i+1]=operand_array[i+2];
                    operators[i]=operators[i+1];
                    i++;
                }
            }
            else
            {
                operand_array[i]=operand_array[i]-operand_array[i+1];
                while(i<no_of_operator){
                    operand_array[i+1]=operand_array[i+2];
                    operators[i]=operators[i+1];
                    i++;
                }
            }
            no_of_operator--;
        }
        else{
            j++;
        }
    }
}

void Display(char *ptr){
      int i=0;
      while(ptr[i]!=0){
          result[i]=ptr[i];
          i++;
      }
      no_of_operator=0;
      memset(operators,0,sizeof(operators));
      memset(operand,0,sizeof(operand));
      memset(operand_array,0,sizeof(operand_array));

}

void result_update(void){
    if(operators[0]==0 && operand_array[0]!=0){
        memset(char_pressed,0,sizeof(char_pressed));
        index=0;
        memset(disp_array,0,sizeof(disp_array));
        disp_in=0;

        if(operand_array[0]<0){
            char_pressed[0]='-';
            ftoa((0-operand_array[0]), &char_pressed[1], 4);
            disp_array[0]='-';
            ftoa((0-operand_array[0]), &disp_array[1], 4);
        }
        else{
            ftoa(operand_array[0], char_pressed, 4);
            ftoa(operand_array[0], disp_array, 4);
        }

        index=strlen(char_pressed);
        disp_in=strlen(disp_array);
        operand_array[0]=0;
    }
}
