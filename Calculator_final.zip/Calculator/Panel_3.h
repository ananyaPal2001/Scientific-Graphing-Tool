
#ifndef PANEL_3_H_
#define PANEL_3_H_

#include "Initial_1.h"
#include"all_functions.h"

//*****************************************************************************
//
// third panel
//
//*****************************************************************************
Canvas(g_sCanvas_43, g_psPanels+3, 0, 0,
       &g_sKentec320x240x16_SSD2119, 120, 33, 200, 33,
       CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT,
       ClrBlue, ClrGray, ClrSilver, &g_sFontCm22, 0, 0, 0);

Canvas(g_sCanvas_33, g_psPanels+3,&g_sCanvas_43 , 0,
       &g_sKentec320x240x16_SSD2119, 0, 33, 120, 33,
       CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT,
       ClrBlue, ClrGray, ClrSilver, &g_sFontCm22, 0, 0, 0);
Canvas(g_sCanvas_23, g_psPanels+3, &g_sCanvas_33, 0,
       &g_sKentec320x240x16_SSD2119, 120, 0, 200, 33,
       CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT,
       ClrBlue, ClrGray, ClrSilver, &g_sFontCm22, 0, 0, 0);

Canvas(g_sCanvas_13, g_psPanels+3,&g_sCanvas_23 , 0,
       &g_sKentec320x240x16_SSD2119, 0, 0, 120, 33,
       CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT,
       ClrBlue, ClrGray, ClrSilver, &g_sFontCm22, 0, 0, 0);


tPushButtonWidget g_psPushButtons_3[] =
{
    RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3 + 1, 0,
                            &g_sKentec320x240x16_SSD2119, 0, 68, 40, 40,
                            PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                           ClrBlue, ClrBlack, ClrGray, ClrSilver,
                            &g_sFontCm22, "1", 0, 0, 0, 0, OnButtonPress_3),
    RectangularButtonStruct(g_psPanels +2, g_psPushButtons_3 + 2, 0,
                         &g_sKentec320x240x16_SSD2119, 40 , 68, 40, 40,
                         PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                         ClrBlue, ClrBlack, ClrGray, ClrSilver,
                          &g_sFontCm22, "2", 0, 0, 0, 0, OnButtonPress_3),
    RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3 + 3, 0,
                            &g_sKentec320x240x16_SSD2119, 80, 68, 40, 40,
                            PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                            ClrBlue, ClrBlack, ClrGray, ClrSilver,
                            &g_sFontCm22, "3", 0, 0, 0, 0, OnButtonPress_3),
  RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3 + 4, 0,
                           &g_sKentec320x240x16_SSD2119, 0, 112, 40, 40,
                           PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                           ClrBlue, ClrBlack, ClrGray, ClrSilver,
                           &g_sFontCm22, "4", 0, 0, 0, 0, OnButtonPress_3),
 RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3 + 5, 0,
                         &g_sKentec320x240x16_SSD2119, 40 , 112, 40, 40,
                         PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                         ClrBlue, ClrBlack, ClrGray, ClrSilver,
                          &g_sFontCm22, "5", 0, 0, 0, 0, OnButtonPress_3),

RectangularButtonStruct(g_psPanels+3 , g_psPushButtons_3 + 6, 0,
                        &g_sKentec320x240x16_SSD2119, 80 , 112, 40, 40,
                      PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                         ClrBlue, ClrBlack, ClrGray, ClrSilver,
                      &g_sFontCm22, "6", 0, 0, 0, 0, OnButtonPress_3),
 RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3 + 7, 0,
                         &g_sKentec320x240x16_SSD2119, 0 , 156, 40, 40,
                         PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                          ClrBlue, ClrBlack, ClrGray, ClrSilver,
                         &g_sFontCm22, "7", 0, 0, 0, 0, OnButtonPress_3),

RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3 + 8, 0,
                        &g_sKentec320x240x16_SSD2119, 40 , 156, 40, 40,
                        PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                         ClrBlue, ClrBlack, ClrGray, ClrSilver,
                        &g_sFontCm22, "8", 0, 0, 0, 0, OnButtonPress_3),
RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3 + 9, 0,
                        &g_sKentec320x240x16_SSD2119, 80 , 156, 40, 40,
                         PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                         ClrBlue, ClrBlack, ClrGray, ClrSilver,
                          &g_sFontCm22, "9", 0, 0, 0, 0, OnButtonPress_3),
RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3 + 10, 0,
                       &g_sKentec320x240x16_SSD2119, 40 , 200, 40, 40,
                      PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                     ClrBlue, ClrBlack, ClrGray, ClrSilver,
                      &g_sFontCm22, "0", 0, 0, 0, 0, OnButtonPress_3),
RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3 + 11, 0,
                        &g_sKentec320x240x16_SSD2119, 80 , 200, 40, 40,
                       PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                      ClrBlue, ClrBlack, ClrGray, ClrSilver,
                       &g_sFontCm22, ".", 0, 0, 0, 0, OnButtonPress_3),
RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3+12, 0, &g_sKentec320x240x16_SSD2119, 120 , 68, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrBlue, ClrBlack, ClrGray, ClrSilver,
                      &g_sFontCm14, "A", 0, 0, 0, 0, OnButtonPress_3),
RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3+13, 0, &g_sKentec320x240x16_SSD2119, 160 , 68, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrBlue, ClrBlack, ClrGray, ClrSilver,
                       &g_sFontCm14, "E", 0, 0, 0, 0, OnButtonPress_3),
RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3 + 14, 0,
                        &g_sKentec320x240x16_SSD2119, 200 , 68, 80, 40,
                       PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                      ClrBlue, ClrBlack, ClrGray, ClrSilver,
                       &g_sFontCm12, "DEC TO BIN", 0, 0, 0, 0, OnButtonPress_3),

RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3+15, 0,
                        &g_sKentec320x240x16_SSD2119, 280 , 68, 40, 40,
                         PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                          ClrBlue, ClrBlack, ClrGray, ClrSilver,
                        &g_sFontCm18, "=", 0, 0, 0, 0, OnButtonPress_3),
 RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3+16, 0, &g_sKentec320x240x16_SSD2119, 120 , 112, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrBlue, ClrBlack, ClrGray, ClrSilver,
                        &g_sFontCm14, "B", 0, 0, 0, 0, OnButtonPress_3),
 RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3+17, 0,
                         &g_sKentec320x240x16_SSD2119, 160 , 112, 40, 40,
                       PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                       ClrBlue, ClrBlack, ClrGray, ClrSilver,
                        &g_sFontCm16, "F", 0, 0, 0, 0, OnButtonPress_3),

RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3+18, 0, &g_sKentec320x240x16_SSD2119, 200 , 112, 120, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrBlue, ClrBlack, ClrGray, ClrSilver,
                        &g_sFontCm14, "BIN TO DEC", 0, 0, 0, 0, OnButtonPress_3),

RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3+19, 0, &g_sKentec320x240x16_SSD2119, 120 , 156, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrBlue, ClrBlack, ClrGray, ClrSilver,
                                                &g_sFontCm18, "C", 0, 0, 0, 0, OnButtonPress_3),
RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3+20, 0,
                        &g_sKentec320x240x16_SSD2119, 160 , 156, 40, 40,
                        PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                        ClrBlue, ClrBlack, ClrGray, ClrSilver,
                        &g_sFontCm16, "CR", 0, 0, 0, 0, OnButtonPress_3),

RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3+21, 0, &g_sKentec320x240x16_SSD2119, 200 , 156, 120, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrBlue, ClrBlack, ClrGray, ClrSilver,
                        &g_sFontCm14, "DEC TO HEX", 0, 0, 0, 0, OnButtonPress_3),
RectangularButtonStruct(g_psPanels+3, g_psPushButtons_3+22, 0, &g_sKentec320x240x16_SSD2119, 120 , 200, 40, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrBlue, ClrBlack, ClrGray, ClrSilver,
                       &g_sFontCm14, "D", 0, 0, 0, 0, OnButtonPress_3),
 RectangularButtonStruct(g_psPanels+3,g_psPushButtons_3+23 , 0,
                          &g_sKentec320x240x16_SSD2119, 160 , 200, 40, 40,
                           PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                            ClrBlue, ClrBlack, ClrGray, ClrSilver,
                          &g_sFontCm16, "Del", 0, 0, 0, 0, OnButtonPress_3),
RectangularButtonStruct(g_psPanels+3, &g_sCanvas_13, 0, &g_sKentec320x240x16_SSD2119, 200 , 200, 120, 40,PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,ClrBlue, ClrBlack, ClrGray, ClrSilver,
                       &g_sFontCm14, "HEX TO DEC", 0, 0, 0, 0, OnButtonPress_3),



};
int NUM_PUSH_BUTTONS_3=(sizeof(g_psPushButtons_3) /sizeof(g_psPushButtons_3[0]));
uint32_t g_ui32ButtonState_3;


#endif /* PANEL_3_H_ */
