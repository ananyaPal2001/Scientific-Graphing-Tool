#ifndef PANEL_6_2_H_
#define PANEL_6_2_H_


#include "Initial_1.h"
#include"all_functions.h"
#include "evaluate.h"

void OnButtonPress_6_2(tWidget *psWidget, tContext *psContext);

Canvas(g_sCanvas_162, g_psPanels+7, 0 , 0,
       &g_sKentec320x240x16_SSD2119, 0, 0, 340, 200,
       CANVAS_STYLE_OUTLINE | CANVAS_STYLE_APP_DRAWN,
       0, ClrGray, 0, 0, 0, 0, OnButtonPress_6_2);

tPushButtonWidget g_psPushButtons_6_2[] =
{
    RectangularButtonStruct(g_psPanels+7, g_psPushButtons_6_2 + 1, 0,
                            &g_sKentec320x240x16_SSD2119, 40 , 200, 40, 40,
                            PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                            ClrGreen, ClrBlack, ClrYellow, ClrWhite,
                            &g_sFontCm16, btn1, 0, 0, 0, 0, ButtonPress_Plot),
    RectangularButtonStruct(g_psPanels+7, g_psPushButtons_6_2 + 2, 0,
                            &g_sKentec320x240x16_SSD2119, 80 , 200, 40, 40,
                            PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                            ClrGreen, ClrBlack, ClrYellow, ClrWhite,
                            &g_sFontCm16, btn2, 0, 0, 0, 0, ButtonPress_Plot),
    RectangularButtonStruct(g_psPanels+7, g_psPushButtons_6_2 + 3, 0,
                            &g_sKentec320x240x16_SSD2119, 120 , 200, 40, 40,
                            PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                            ClrGreen, ClrBlack, ClrYellow, ClrWhite,
                            &g_sFontCm16, btn3, 0, 0, 0, 0, ButtonPress_Plot),
    RectangularButtonStruct(g_psPanels+7, g_psPushButtons_6_2 + 4, 0,
                            &g_sKentec320x240x16_SSD2119, 160 , 200, 40, 40,
                            PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                            ClrGreen, ClrBlack, ClrYellow, ClrWhite,
                            &g_sFontCm16, btn4, 0, 0, 0, 0, ButtonPress_Plot),
    RectangularButtonStruct(g_psPanels+7, g_psPushButtons_6_2 + 5, 0,
                            &g_sKentec320x240x16_SSD2119, 200 , 200, 40, 40,
                            PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                            ClrGreen, ClrBlack, ClrYellow, ClrWhite,
                            &g_sFontCm16, btn5, 0, 0, 0, 0, ButtonPress_Plot),
    RectangularButtonStruct(g_psPanels+7, g_psPushButtons_6_2 + 6, 0,
                             &g_sKentec320x240x16_SSD2119, 240 , 200, 40, 40,
                             PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                             ClrGreen, ClrBlack, ClrYellow, ClrWhite,
                             &g_sFontCm12, btn6, 0, 0, 0, 0, ButtonPress_Plot),
    RectangularButtonStruct(g_psPanels+7, &g_sCanvas_162, 0,
                             &g_sKentec320x240x16_SSD2119, 280 , 200, 40, 40,
                             PB_STYLE_FILL | PB_STYLE_OUTLINE | PB_STYLE_TEXT,
                             ClrRed, ClrBlack, ClrYellow, ClrWhite,
                             &g_sFontCm16, btn7, 0, 0, 0, 0, ButtonPress_Plot),

};

int NUM_PUSH_BUTTONS_6_2 =(sizeof(g_psPushButtons_6_2) / sizeof(g_psPushButtons_6_2[0]));
uint32_t g_ui32ButtonState_6_2;

#endif
