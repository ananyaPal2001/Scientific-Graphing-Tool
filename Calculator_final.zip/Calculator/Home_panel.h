
#ifndef HOME_PANEL_H_
#define HOME_PANEL_H_

#include "Initial_1.h"
#include"all_functions.h"



Canvas(g_sCanvas_home, g_psPanels,0 , 0,
       &g_sKentec320x240x16_SSD2119, 0, 0, 320, 30,
       CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT,
       ClrGreen, ClrYellow, ClrWhite, &g_sFontCm20b, "ESD Mini-Project", 0, 0);


tPushButtonWidget g_psPushButtons_home[] =
{
 RectangularButtonStruct(g_psPanels , g_psPushButtons_home+1, 0,
                         &g_sKentec320x240x16_SSD2119, 0, 40, 150, 80,
                         (PB_STYLE_OUTLINE | PB_STYLE_TEXT_OPAQUE | PB_STYLE_TEXT |
                          PB_STYLE_FILL), ClrGreen, ClrBlack, ClrYellow, ClrWhite,
                         g_psFontCmss12b, "Basic", 0, 0, 0, 0, OnNext),
 RectangularButtonStruct(g_psPanels , g_psPushButtons_home+2, 0,
                         &g_sKentec320x240x16_SSD2119, 160, 40, 150, 80,
                         (PB_STYLE_OUTLINE | PB_STYLE_TEXT_OPAQUE | PB_STYLE_TEXT |
                          PB_STYLE_FILL), ClrGreen, ClrBlack, ClrYellow, ClrWhite,
                          g_psFontCmss12b, "Trigonometric", 0, 0, 0, 0, OnNext),
RectangularButtonStruct(g_psPanels , g_psPushButtons_home+3, 0,
                      &g_sKentec320x240x16_SSD2119,0, 140, 150, 80,
                      (PB_STYLE_OUTLINE | PB_STYLE_TEXT_OPAQUE | PB_STYLE_TEXT |
                      PB_STYLE_FILL),ClrGreen, ClrBlack, ClrYellow, ClrWhite,
                       g_psFontCmss12b, "Data Conversion", 0, 0, 0, 0, OnNext),
//RectangularButtonStruct(g_psPanels , g_psPushButtons_home+4, 0,
//                      &g_sKentec320x240x16_SSD2119, 0, 140, 100, 80,
//                      (PB_STYLE_OUTLINE | PB_STYLE_TEXT_OPAQUE | PB_STYLE_TEXT |
//                      PB_STYLE_FILL),ClrGreen, ClrBlack, ClrYellow, ClrWhite,
//                      g_psFontCmss12b, "Equation solver", 0, 0, 0, 0, OnNext),
//RectangularButtonStruct(g_psPanels , g_psPushButtons_home+5, 0,
//                      &g_sKentec320x240x16_SSD2119, 110, 140, 100, 80,
//                      (PB_STYLE_OUTLINE | PB_STYLE_TEXT_OPAQUE | PB_STYLE_TEXT |
//                      PB_STYLE_FILL),ClrGreen, ClrBlack, ClrYellow, ClrWhite,
//                        g_psFontCmss12b, "Functions", 0, 0, 0, 0, OnNext),
RectangularButtonStruct(g_psPanels , &g_sCanvas_home, 0,
                      &g_sKentec320x240x16_SSD2119, 160, 140, 150, 80,
                      (PB_STYLE_OUTLINE | PB_STYLE_TEXT_OPAQUE | PB_STYLE_TEXT |
                      PB_STYLE_FILL),ClrGreen, ClrBlack, ClrYellow, ClrWhite,
                        g_psFontCmss12b, "Graph Plotter", 0, 0, 0, 0, OnNext),
};
int Home_buttons=(sizeof(g_psPushButtons_home) /sizeof(g_psPushButtons_home[0]));

#endif
