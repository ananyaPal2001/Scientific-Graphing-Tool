
#ifndef ALL_FUNCTIONS_H_
#define ALL_FUNCTIONS_H_



void OnPrevious(tWidget *psWidget);
void OnNext(tWidget *psWidget);
void OnButtonPress_1(tWidget *psWidget);
void OnButtonPress_2(tWidget *psWidget);
void OnButtonPress_3(tWidget *psWidget);
void OnButtonPress_4(tWidget *psWidget);
void OnButtonPress_5(tWidget *psWidget);
//********** Graph Plotter Panel **********//
void OnButtonPress_6(tWidget *psWidget);
void OnButtonPress_6_2(tWidget *psWidget, tContext *psContext);
void ButtonPress_Plot(tWidget *psWidget);

extern tCanvasWidget g_psPanels[];
extern tPushButtonWidget g_psPushButtons_home[];
extern tCanvasWidget g_sCanvas_home;
extern tPushButtonWidget g_sPrevious;
extern tCanvasWidget g_sTitle;
extern tPushButtonWidget g_psPushButtons_1[];
extern tCanvasWidget g_sCanvas_11;
extern tCanvasWidget g_sCanvas_21;
extern tPushButtonWidget g_psPushButtons_2[];
extern tCanvasWidget g_sCanvas_12;
extern tCanvasWidget g_sCanvas_22;
extern tPushButtonWidget g_psPushButtons_3[];
extern tCanvasWidget g_sCanvas_13;
extern tCanvasWidget g_sCanvas_23;
extern tCanvasWidget g_sCanvas_33;
extern tCanvasWidget g_sCanvas_43;
extern tPushButtonWidget g_psPushButtons_4[];
extern tCanvasWidget g_sCanvas_14;
extern tCanvasWidget g_sCanvas_24;
extern tCanvasWidget g_sCanvas_24;
extern tCanvasWidget g_sCanvas_44;
extern tCanvasWidget g_sCanvas_54;
extern tCanvasWidget g_sCanvas_64;
extern tPushButtonWidget g_psPushButtons_5[];
extern tCanvasWidget g_sCanvas_15;
extern tCanvasWidget g_sCanvas_25;
//********** Graph Plotter Panel **********//
extern tPushButtonWidget g_psPushButtons_6[];
extern tCanvasWidget g_sCanvas_16;
extern tCanvasWidget g_sCanvas_26;
extern tPushButtonWidget g_psPushButtons_6_2[];
extern tCanvasWidget g_sCanvas_162;
//*****************************************************************************
//
// The names for each of the panels, which is displayed at the bottom of the
// screen.
//
//*****************************************************************************
extern char *g_pcPanei32Names[] ;

uint32_t g_ui32Panel;


#endif
