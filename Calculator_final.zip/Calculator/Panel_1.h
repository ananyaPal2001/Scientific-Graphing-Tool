
#ifndef PANEL_1_H_
#define PANEL_1_H_


#include "Initial_1.h"
#include"all_functions.h"

extern tPushButtonWidget g_psPushButtons_1[];
extern tCanvasWidget g_sCanvas_11;
extern tCanvasWidget g_sCanvas_21;
//*****************************************************************************
//
// First Pannel
//
//*****************************************************************************

Canvas(g_sCanvas_21, g_psPanels+1, 0, 0,
       &g_sKentec320x240x16_SSD2119, 0, 33, 340, 33,
       CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT,
       ClrBlack, ClrGray, ClrSilver, &g_sFontCm22, 0, 0, 0);

Canvas(g_sCanvas_11, g_psPanels+1,&g_sCanvas_21 , 0,
       &g_sKentec320x240x16_SSD2119, 0, 0, 340, 33,
       CANVAS_STYLE_FILL | CANVAS_STYLE_OUTLINE | CANVAS_STYLE_TEXT,
       ClrGray, ClrGray, ClrSilver, &g_sFontCm22, 0, 0, 0);

tPushButtonWidget g_psPushButtons_1[] =
{
 RectangularButtonStruct(g_psPanels , g_psPushButtons_1 + 1, 0,
                          &g_sKentec320x240x16_SSD2119, 0, 68, 40, 40,
                          PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                          &g_sFontCm22, "1", g_pui8Blue50x50,
                          g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1 + 2, 0,
                          &g_sKentec320x240x16_SSD2119, 40, 68, 40, 40,
                          PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                          &g_sFontCm22, "2", g_pui8Blue50x50,
                          g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1 + 3, 0,
                           &g_sKentec320x240x16_SSD2119, 80, 68, 40, 40,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "3", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1 + 4, 0,
                           &g_sKentec320x240x16_SSD2119, 0, 112, 40, 40,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "4", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1 + 5, 0,
                           &g_sKentec320x240x16_SSD2119, 40, 112, 40, 40,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "5", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1+6, 0,
                           &g_sKentec320x240x16_SSD2119, 80, 112, 40, 40,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "6", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1 + 7, 0,
                           &g_sKentec320x240x16_SSD2119, 0, 156, 40, 40,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "7", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1 + 8, 0,
                           &g_sKentec320x240x16_SSD2119, 40, 156, 40, 40,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "8", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1 + 9, 0,
                           &g_sKentec320x240x16_SSD2119, 80, 156, 40, 40,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "9", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1 + 10, 0,
                           &g_sKentec320x240x16_SSD2119, 40, 200, 40, 40,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "0", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1+11, 0,
                           &g_sKentec320x240x16_SSD2119, 80, 200, 40, 40,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, ".", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1+12, 0,
                           &g_sKentec320x240x16_SSD2119, 120, 68, 50, 50,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "AC", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1+13, 0,
                           &g_sKentec320x240x16_SSD2119, 170, 68, 50, 50,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "DEL", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1+14, 0,
                           &g_sKentec320x240x16_SSD2119, 220, 68, 50, 50,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "=", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1+15, 0,
                           &g_sKentec320x240x16_SSD2119, 120, 118, 50, 50,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "+", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1+16, 0,
                           &g_sKentec320x240x16_SSD2119, 170, 118, 50, 50,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "-", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, g_psPushButtons_1+17, 0,
                           &g_sKentec320x240x16_SSD2119, 120, 168, 50, 50,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "*", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
   RectangularButtonStruct(g_psPanels + 1, 0, 0,
                           &g_sKentec320x240x16_SSD2119, 170, 168, 50, 50,
                           PB_STYLE_IMG | PB_STYLE_TEXT, 0, 0, 0, ClrSilver,
                           &g_sFontCm22, "/", g_pui8Blue50x50,
                           g_pui8Blue50x50Press, 0, 0, OnButtonPress_1),
};
int NUM_PUSH_BUTTONS_1=(sizeof(g_psPushButtons_1) / sizeof(g_psPushButtons_1[0]));
uint32_t g_ui32ButtonState_1;

#endif
