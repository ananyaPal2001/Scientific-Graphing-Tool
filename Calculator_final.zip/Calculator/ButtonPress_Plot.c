#include "Initial_1.h"
#include"all_functions.h"
#include "evaluate.h"

void Eval_function_6(void);


void ButtonPress_Plot(tWidget *psWidget)
{
    uint32_t button_6_2;

    for(button_6_2 = 0; button_6_2 < NUM_PUSH_BUTTONS_6_2; button_6_2++)
    {
        if(psWidget == (tWidget *)(g_psPushButtons_6_2 + button_6_2))
        {
            break;
        }
    }

    if(button_6_2 == NUM_PUSH_BUTTONS_6)
    {
        return;
    }

    if(change_btn == 0) {
    switch(button_6_2)
    {
        case 0:
            zoom_in();
            WidgetRemove((tWidget *)(g_psPanels + 7));
            WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
            WidgetPaint((tWidget *)(g_psPanels + 7));
            PushButtonFillOn(&g_sPrevious);
            PushButtonTextOn(&g_sPrevious);
            WidgetPaint((tWidget *)&g_sPrevious);
            break;
        case 1:
            zoom_out();
            WidgetRemove((tWidget *)(g_psPanels + 7));
            WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
            WidgetPaint((tWidget *)(g_psPanels + 7));
            PushButtonFillOn(&g_sPrevious);
            PushButtonTextOn(&g_sPrevious);
            WidgetPaint((tWidget *)&g_sPrevious);
            break;
        case 2:
            shift_left();
            WidgetRemove((tWidget *)(g_psPanels + 7));
            WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
            WidgetPaint((tWidget *)(g_psPanels + 7));
            PushButtonFillOn(&g_sPrevious);
            PushButtonTextOn(&g_sPrevious);
            WidgetPaint((tWidget *)&g_sPrevious);
            break;
        case 3:
            shift_right();
            WidgetRemove((tWidget *)(g_psPanels + 7));
            WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
            WidgetPaint((tWidget *)(g_psPanels + 7));
            PushButtonFillOn(&g_sPrevious);
            PushButtonTextOn(&g_sPrevious);
            WidgetPaint((tWidget *)&g_sPrevious);
            break;
        case 4:
            derivative();
            map_dx_dy();
            WidgetRemove((tWidget *)(g_psPanels + 7));
            WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
            WidgetPaint((tWidget *)(g_psPanels + 7));
            PushButtonFillOn(&g_sPrevious);
            PushButtonTextOn(&g_sPrevious);
            WidgetPaint((tWidget *)&g_sPrevious);
            break;
        case 5:
            integral();
            map_integral();
            WidgetRemove((tWidget *)(g_psPanels + 7));
            WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
            WidgetPaint((tWidget *)(g_psPanels + 7));
            PushButtonFillOn(&g_sPrevious);
            PushButtonTextOn(&g_sPrevious);
            WidgetPaint((tWidget *)&g_sPrevious);
            break;
        case 6:
            map_xy();
            WidgetRemove((tWidget *)(g_psPanels + 7));
            WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
            WidgetPaint((tWidget *)(g_psPanels + 7));
            PushButtonFillOn(&g_sPrevious);
            PushButtonTextOn(&g_sPrevious);
            WidgetPaint((tWidget *)&g_sPrevious);
            strcpy(btn1," ");
            strcpy(btn2," ");
            strcpy(btn3,"hide");
            strcpy(btn4,"f(x)");
            strcpy(btn5,"A");
            strcpy(btn6,"Roots");
            strcpy(btn7,"2/2");
            change_btn = 1;
            break;
        default:
            return;
    }
    } else {
        switch(button_6_2)
        {
            case 0:
                zoom_in();
                WidgetRemove((tWidget *)(g_psPanels + 7));
                WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
                WidgetPaint((tWidget *)(g_psPanels + 7));
                PushButtonFillOn(&g_sPrevious);
                PushButtonTextOn(&g_sPrevious);
                WidgetPaint((tWidget *)&g_sPrevious);
                break;
            case 1:
                isTextVisible = 1;
                maxima_minima_of_function();
                map_maxima_minima();
                WidgetRemove((tWidget *)(g_psPanels + 7));
                WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
                WidgetPaint((tWidget *)(g_psPanels + 7));
                PushButtonFillOn(&g_sPrevious);
                PushButtonTextOn(&g_sPrevious);
                WidgetPaint((tWidget *)&g_sPrevious);
                break;
            case 2:
                //hide x coord
                isTextVisible = 0;
                WidgetRemove((tWidget *)(g_psPanels + 7));
                WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
                WidgetPaint((tWidget *)(g_psPanels + 7));
                PushButtonFillOn(&g_sPrevious);
                PushButtonTextOn(&g_sPrevious);
                WidgetPaint((tWidget *)&g_sPrevious);
                break;
            case 3:
                map_xy();
                WidgetRemove((tWidget *)(g_psPanels + 7));
                WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
                WidgetPaint((tWidget *)(g_psPanels + 7));
                PushButtonFillOn(&g_sPrevious);
                PushButtonTextOn(&g_sPrevious);
                WidgetPaint((tWidget *)&g_sPrevious);
                break;
            case 4:
                // Area under the curve
                isTextVisible = 1;
                map_xy();
                area_under_curve();
                WidgetRemove((tWidget *)(g_psPanels + 7));
                WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
                WidgetPaint((tWidget *)(g_psPanels + 7));
                PushButtonFillOn(&g_sPrevious);
                PushButtonTextOn(&g_sPrevious);
                WidgetPaint((tWidget *)&g_sPrevious);
                break;
            case 5:
                // roots
                isTextVisible = 1;
                map_xy();
                zeros_of_function();
                map_zeros();
                WidgetRemove((tWidget *)(g_psPanels + 7));
                WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
                WidgetPaint((tWidget *)(g_psPanels + 7));
                PushButtonFillOn(&g_sPrevious);
                PushButtonTextOn(&g_sPrevious);
                WidgetPaint((tWidget *)&g_sPrevious);
                break;
            case 6:
                map_xy();
                WidgetRemove((tWidget *)(g_psPanels + 7));
                WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + 7));
                WidgetPaint((tWidget *)(g_psPanels + 7));
                PushButtonFillOn(&g_sPrevious);
                PushButtonTextOn(&g_sPrevious);
                WidgetPaint((tWidget *)&g_sPrevious);
                strcpy(btn1,"+");
                strcpy(btn2,"-");
                strcpy(btn3,"L");
                strcpy(btn4,"R");
                strcpy(btn5,"f'(x)");
                strcpy(btn6,"F(x)");
                strcpy(btn7,"1/2");
                change_btn = 0;
                break;
            default:
                return;
        }

    }

}
