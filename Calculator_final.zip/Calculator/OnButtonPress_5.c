
#include "Initial_1.h"
#include"all_functions.h"

////fucntions
void Eval_function(void);



void
OnButtonPress_5(tWidget *psWidget)
{
    uint32_t button_5;
    //int pi_var=0;//index adding the pi value to the array

    //
    // Find the index of this push button.
    //
    for(button_5 = 0; button_5 < NUM_PUSH_BUTTONS_5; button_5++)
    {
        if(psWidget == (tWidget *)(g_psPushButtons_5 + button_5))
        {
            break;
        }
    }

    //
    // Return if the push button could not be found.
    //
    if(button_5 == NUM_PUSH_BUTTONS_5)
    {
        return;
    }
    switch(button_5)
        {

        case 0 :
            disp_array[disp_in]='1';
            disp_in++;
            char_pressed[index] = '1';
            index++;
            break;
        case 1 :
            disp_array[disp_in]='2';
            disp_in++;
            char_pressed[index] = '2';
            index++;
            break;
        case 2 :
            disp_array[disp_in]='3';
            disp_in++;
            char_pressed[index] = '3';
            index++;
            break;

        case 3 :
            disp_array[disp_in]='4';
            disp_in++;
            char_pressed[index] = '4';
            index++;
            break;
        case 4 :
            disp_array[disp_in]='5';
            disp_in++;
            char_pressed[index] = '5';
            index++;
            break;

        case 5 :
            disp_array[disp_in]='6';
            disp_in++;
            char_pressed[index]= '6';
            index++;
            break;
        case 6 :
            disp_array[disp_in]='7';
            disp_in++;
            char_pressed[index] = '7';
            index++;
            break;
        case 7 :
            disp_array[disp_in]='8';
            disp_in++;
            char_pressed[index] = '8';
            index++;
            break;
        case 8 :
            disp_array[disp_in]='9';
            disp_in++;
            char_pressed[index] = '9';
            index++;
            break;
        case 9 :
            disp_array[disp_in]='0';
            disp_in++;
            char_pressed[index] = '0';
            index++;
            break;

        case 10 :
            disp_array[disp_in]='.';
            disp_in++;
            char_pressed[index] = '.';
            index++;
            break;

        case 11 :
            memset(char_pressed,0,sizeof(char_pressed));
           memset(disp_array,0,sizeof(disp_array));
           memset(operators,0,sizeof(operators));
           memset(operand,0,sizeof(operand));
           memset(operand_array,0,sizeof(operand_array));
           memset(result,0,sizeof(result));
           disp_in=0;
           index=0;
           CanvasTextSet(&g_sCanvas_25, result);
            WidgetPaint((tWidget *)&g_sCanvas_25);
          // array_in=0;
            break;
        case 12 :
            index--;
            char_pressed[index] = 0;
            disp_in--;
            disp_array[disp_in]=0;
            break;
        case 13 ://x^y
            result_update();
            disp_array[disp_in]='^';
            disp_in++;
            char_pressed[index] = '^';
            index++;
            break;
        case 14 ://1/x
            result_update();
            processing();
            function_index=0;
            Eval_function();
            break;
        case 15 ://=
           processing();
           calculation();
           display_result_5();
            break;
        case 16 ://log
            result_update();
            processing();
            function_index=1;
            Eval_function();
            break;
        case 17 ://ln
            processing();
            function_index=2;
            Eval_function();
            break;
        case 18 ://log base 2
            processing();
            function_index=3;
            Eval_function();
            break;
        case 19 ://exp
            processing();
            function_index=4;
            Eval_function();
            break;
        case 20 ://sqr
            processing();
            function_index=5;
            Eval_function();
            break;
        case 21://sqrt
            processing();
            function_index=6;
            Eval_function();
            break;
        case 22 ://x!
            processing();
            function_index=7;
            Eval_function();
            break;
        case 23 ://npr
            result_update();
            disp_array[disp_in]='P';
            disp_in++;
            char_pressed[index] = 'p';
            index++;
            break;
        case 24 ://ncr
            result_update();
            disp_array[disp_in]='C';
            disp_in++;
            char_pressed[index] = 'c';
            index++;
            break;

        case 25 ://ceil
            processing();
            function_index=8;
            Eval_function();
            break;
        case 26 ://floor
            processing();
            function_index=9;
            Eval_function();
            break;
        case 27 :
            result_update();
            disp_array[disp_in]='+';
            disp_in++;
            char_pressed[index] = '+';
            index++;
            break;
        case 28 :
            result_update();
            disp_array[disp_in]='-';
            disp_in++;
            char_pressed[index] = '-';
            index++;
            break;
        case 29 :
            result_update();
            disp_array[disp_in]='x';
            disp_in++;
            char_pressed[index] = 'x';
            index++;
            break;
        case 30 :
            result_update();
            disp_array[disp_in]='/';
            disp_in++;
            char_pressed[index] = '/';
            index++;
            break;
        default :
            return;
           // break;

        }

        CanvasTextSet(&g_sCanvas_15, disp_array);
        WidgetPaint((tWidget *)&g_sCanvas_15);

    //
    // Toggle the state of this push button indicator.
    //
    g_ui32ButtonState_5 ^= 1 << button_5;



}
void Eval_function(){
    int n=0,number_1;
    while(operators[n]!=0){
        n++;
    }
    if(n==1 && operand_array[0]==0){//checking for single varible negative or positive numbers
        single_num=1;
        calculation();
    }
     int m=0;
     while(operand_array[m]!=0){
         length++;
         m++;
     }

     switch(function_index){
     case 0 :if((operand_array[length-1])==0){
                         memset(result,0,sizeof(result));
                          Display("Math Error");
                          CanvasTextSet(&g_sCanvas_25, result);
                          WidgetPaint((tWidget *)&g_sCanvas_25);
                           return;
             }
             Eval_result=1/(operand_array[length-1]); //find 1/x value
             break;
     case 1 :   if((operand_array[length-1])<=0){
                     memset(result,0,sizeof(result));
                     Display("Math Error");
                     CanvasTextSet(&g_sCanvas_25, result);
                      WidgetPaint((tWidget *)&g_sCanvas_25);
                          return;
                 }

             Eval_result=log10f(operand_array[length-1]); //log base 10
                  break;
     case 2 :
                 if((operand_array[length-1])<=0){
                     memset(result,0,sizeof(result));
                     Display("Math Error");
                     CanvasTextSet(&g_sCanvas_25, result);
                      WidgetPaint((tWidget *)&g_sCanvas_25);
                          return;
                 }
             Eval_result=logf(operand_array[length-1]); //ln value
                  break;
     case 3 :
                 if((operand_array[length-1])<=0){
                     memset(result,0,sizeof(result));
                     Display("Math Error");
                     CanvasTextSet(&g_sCanvas_25, result);
                      WidgetPaint((tWidget *)&g_sCanvas_25);
                          return;
                 }
             Eval_result=log2f(operand_array[length-1]); //log base 2
                  break;
     case 4 :
             Eval_result=expf(operand_array[length-1]); //exp(x)
                  break;
     case 5 :
             Eval_result=(operand_array[length-1])*(operand_array[length-1]); //square
                  break;
     case 6 :
             Eval_result=sqrtf(operand_array[length-1]); //square root
                  break;
     case 7 :
         number_1= (int)(operand_array[length-1]);
             if(number_1<0){
                     memset(result,0,sizeof(result));
                     Display("Math Error");
                     CanvasTextSet(&g_sCanvas_22, result);
                      WidgetPaint((tWidget *)&g_sCanvas_22);
                          return;
                 }
         Eval_result= (float)factorial(number_1); //factorial
                  break;
     case 8 :
             Eval_result=ceilf(operand_array[length-1]); //ceil (x)

                  break;
     case 9 :
             Eval_result=floorf(operand_array[length-1]); //ceil (x)
                  break;
     default:
                 return;
                 //break;
     }

     float d=Eval_result;
     if(Eval_result<0){
         float c=(0-Eval_result);
         ftoa(c,temp,4); //float to char to find lenght
     }
     else{
         ftoa(Eval_result,temp,4); //float to char to find lenght
     }


    int i=0,k=0;
    int j=disp_in-1;//disp_index
    index=index-1;//char_pressed

    while(index!=0){
        if(char_pressed[index-1]=='+'||char_pressed[index-1]=='-'||char_pressed[index-1]=='x'||char_pressed[index-1]=='/'){
            break;
        }

        index--;
    }
    while(temp[i]!=0){
        if(d<0){
            char_pressed[index]='-';
            d=0-d;
            index++;
        }
        else{
            char_pressed[index]=temp[i];//upadating with new sin value
                    i++;
                    index++;
        }


    }

    memset(temp,0,sizeof(temp));
    i=0;
    while(j>=0){
        temp[i]=disp_array[j];
        i++;
        if(single_num){
            single_num=0;
        }
        else if(disp_array[j-1]=='+'||disp_array[j-1]=='-'||disp_array[j-1]=='x'||disp_array[j-1]=='/'){//-,1
           break;
        }

        j--;
    }

    if(j<0){
        j=0;
    }

    switch(function_index){
         case 0 :
             disp_array[j]='(';j++;disp_array[j]='1';j++;disp_array[j]='/';j++;
                 break;
         case 1 :
             disp_array[j]='l';j++;disp_array[j]='o';j++;disp_array[j]='g';j++;disp_array[j]='(';j++;
                      break;
         case 2 :
             disp_array[j]='l';j++;disp_array[j]='n';j++;disp_array[j]='(';j++;
                      break;
         case 3 :
             disp_array[j]='l';j++;disp_array[j]='o';j++;disp_array[j]='g';j++;disp_array[j]='2';j++;disp_array[j]='(';j++;
                      break;
         case 4 :
             disp_array[j]='E';j++;disp_array[j]='x';j++;disp_array[j]='p';j++;disp_array[j]='(';j++;
                      break;
         case 5 :
             disp_array[j]='S';j++;disp_array[j]='q';j++;disp_array[j]='r';j++;disp_array[j]='(';j++;
                      break;
         case 6 :
             disp_array[j]='S';j++;disp_array[j]='q';j++;disp_array[j]='r';j++;disp_array[j]='t';j++;disp_array[j]='(';j++;
                      break;
         case 7 :
             disp_array[j]='F';j++;disp_array[j]='a';j++;disp_array[j]='c';j++;disp_array[j]='t';j++;disp_array[j]='(';j++;
                      break;
         case 8 :
             disp_array[j]='C';j++;disp_array[j]='e';j++;disp_array[j]='i';j++;disp_array[j]='l';j++;disp_array[j]='(';j++;
                      break;
         case 9 :
             disp_array[j]='F';j++;disp_array[j]='l';j++;disp_array[j]='o';j++;disp_array[j]='o';j++;disp_array[j]='l';j++;disp_array[j]='(';j++;
                      break;
         default:
                     return;
                    // break;
         }

    while(temp[k]!=0){
        disp_array[j]=temp[i-1];
        i--;
        j++;
        k++;
    }
    disp_array[j]=')';
    disp_in=j+1;
    memset(temp,0,sizeof(temp));

    operand_array[length-1]=Eval_result;

    if(Eval_result<0){
        result[0]='-';
        float b=(0-Eval_result);
        ftoa(b, &result[1], 4);
        CanvasTextSet(&g_sCanvas_25, result);
        WidgetPaint((tWidget *)&g_sCanvas_25);
    }
    else {
        ftoa(Eval_result, result, 4);
        CanvasTextSet(&g_sCanvas_25, result);
        WidgetPaint((tWidget *)&g_sCanvas_25);
    }
    length=0;
    m=0;
}
//********factorial********************
long int factorial(int n) {
    if (n>=1)
        return n*factorial(n-1);
    else
        return 1;
}
void display_result_5(void){
    if(operand_array[0]<0){
        result[0]='-';
        float a=(0-operand_array[0]);
        ftoa(a, &result[1], 4);
        CanvasTextSet(&g_sCanvas_25, result);
        WidgetPaint((tWidget *)&g_sCanvas_25);
    }
    else if(operand_array[0]>0){
        ftoa(operand_array[0], result, 4);
        CanvasTextSet(&g_sCanvas_25, result);
        WidgetPaint((tWidget *)&g_sCanvas_25);
    }
    else{
        CanvasTextSet(&g_sCanvas_25, result);
                WidgetPaint((tWidget *)&g_sCanvas_25);
    }


}
